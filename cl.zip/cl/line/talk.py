# -*- coding: utf-8 -*-
from akad.ttypes import Message
from humanfriendly import format_timespan
from random import randint
from multiprocessing import Pool, Process
from threading import Thread
import os, sys, traceback, re, ast, string, time, random, requests
import time, random, signal, pytz, subprocess, atexit, ctypes, livejson, sys, shutil, json, codecs, ast, threading, glob, re, string, asyncio, os, traceback, requests, six, urllib, urllib.parse
import json, ntpath, codecs, livejson, threading
import platform

def loggedIn(func):
    def checkLogin(*args, **kwargs):
        if args[0].isLogin:
            return func(*args, **kwargs)
        else:
            args[0].callback.other('You want to call the function, you must login to LINE')
    return checkLogin

class Talk(object):
    isLogin = False
    _messageReq = {}
    _unsendMessageReq = 0

    def __init__(self):
        self.isLogin = True
        self.loadData()

    """User"""

    @loggedIn
    def acquireEncryptedAccessToken(self, featureType=2):
        return self.talk.acquireEncryptedAccessToken(featureType)

    @loggedIn
    def getProfile(self):
        return self.talk.getProfile()

    @loggedIn
    def getSettings(self):
        return self.talk.getSettings()

    @loggedIn
    def getUserTicket(self):
        return self.talk.getUserTicket()

    @loggedIn
    def updateProfile(self, profileObject):
        return self.talk.updateProfile(0, profileObject)

    @loggedIn
    def updateProfileName(self, to, name):
        if len(name.split("\n")) >= 2:xyzr = self.profile;xyzr.displayName = name.replace(name.split("\n")[0]+"\n","");self.updateProfileAttribute(2, xyzr.displayName);self.sendMessage(to, "DisplayName has been updated to :\n%s" % (self.profile.displayName))
    
    @loggedIn
    def updateProfileStatus(self, to, status):
        if len(status.split("\n")) >= 2:xyzr = self.profile;xyzr.statusMessage = status.replace(status.split("\n")[0]+"\n","");self.updateProfileAttribute(16, xyzr.statusMessage);self.sendMessage(to, "StatusMessage has been updated to :\n%s" % (self.profile.statusMessage))

    @loggedIn
    def updateSettings(self, settingObject):
        return self.talk.updateSettings(0, settingObject)

    @loggedIn
    def updateProfileAttribute(self, attrId, value):
        return self.talk.updateProfileAttribute(0, attrId, value)

    """Operation"""

    @loggedIn
    def fetchOperation(self, revision, count):
        return self.talk.fetchOperations(revision, count)

    @loggedIn
    def getLastOpRevision(self):
        return self.talk.getLastOpRevision()

    """Message"""

    @loggedIn
    def sendMessage(self, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self._messageReq:
            self._messageReq[to] = -1
        self._messageReq[to] += 1
        return self.talk.sendMessage(self._messageReq[to], msg)
    
    """ Usage:
        @to Integer
        @text String
        @dataMid List of user Mid
    """
    @loggedIn
    def sendMessageWithMention(self, to, text='', dataMid=[]):
        arr = []
        list_text=''
        if '[list]' in text.lower():
            i=0
            for l in dataMid:
                list_text+='\n@[list-'+str(i)+']'
                i=i+1
            text=text.replace('[list]', list_text)
        elif '[list-' in text.lower():
            text=text
        else:
            i=0
            for l in dataMid:
                list_text+=' @[list-'+str(i)+']'
                i=i+1
            text=text+list_text
        i=0
        for l in dataMid:
            mid=l
            name='@[list-'+str(i)+']'
            ln_text=text.replace('\n',' ')
            if ln_text.find(name):
                line_s=int(ln_text.index(name))
                line_e=(int(line_s)+int(len(name)))
            arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
            arr.append(arrData)
            i=i+1
        contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self.sendMessage(to, text, contentMetadata)



    def sendMentioncok(self, to, text="", mids=[], senderIcon="", senderName=""):
      arrData = ""
      arr = []
      mention = "@team_silent "
      if mids == []:
        raise Exception("Invalid mids")
      if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ''
        h = ''
        for mid in range(len(mids)):
            h+= str(texts[mid].encode('unicode-escape'))
            textx += str(texts[mid])
            if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 9
            else:slen = len(textx);elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
      else:
        textx = ''
        slen = len(textx)
        elen = len(textx) + 18
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
      self.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}'), 'MSG_SENDER_ICON': senderIcon, 'MSG_SENDER_NAME': senderName}, 0)

    @loggedIn
    def sendMention(self, to, text="", mids=[]):
        arrData = ""
        arr = []
        mention = "@SILENT X "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 10
                else:slen = len(textx);elen = len(textx) + 18
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        self.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

    @loggedIn
    def newMention(self, to, title, mids=[]):
        for mid in range(len(mids)//20+1):
            if mid == 0:txt = ' 「 %s 」\n' % title;no=mid
            else:txt = '';no=mid*20
            xyz = txt
            for result in mids[mid*20:(mid+1)*20]:
                no+=1
                if no == len(mids):xyz += '%i. @!\n' % no
                else:xyz += '%i. @!\n' % no
            self.sendMention(to, xyz.strip(), mids[mid*20:(mid+1)*20])

    @loggedIn
    def sendSticker(self, to, packageId, stickerId):
        contentMetadata = {
            'STKVER': '100',
            'STKPKGID': packageId,
            'STKID': stickerId
        }
        return self.sendMessage(to, '', contentMetadata, 7)
        
    @loggedIn
    def sendContact(self, to, mid):
        contentMetadata = {'mid': mid}
        return self.sendMessage(to, '', contentMetadata, 13)

    @loggedIn
    def sendGift(self, to, productId, productType):
        if productType not in ['theme','sticker']:
            raise Exception('Invalid productType value')
        contentMetadata = {
            'MSGTPL': str(randint(0, 12)),
            'PRDTYPE': productType.upper(),
            'STKPKGID' if productType == 'sticker' else 'PRDID': productId
        }
        return self.sendMessage(to, '', contentMetadata, 9)

    @loggedIn
    def sendMessageAwaitCommit(self, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self._messageReq:
            self._messageReq[to] = -1
        self._messageReq[to] += 1
        return self.talk.sendMessageAwaitCommit(self._messageReq[to], msg)

    @loggedIn
    def unsendMessage(self, messageId):
        self._unsendMessageReq += 1
        return self.talk.unsendMessage(self._unsendMessageReq, messageId)

    @loggedIn
    def requestResendMessage(self, senderMid, messageId):
        return self.talk.requestResendMessage(0, senderMid, messageId)

    @loggedIn
    def respondResendMessage(self, receiverMid, originalMessageId, resendMessage, errorCode):
        return self.talk.respondResendMessage(0, receiverMid, originalMessageId, resendMessage, errorCode)

    @loggedIn
    def removeMessage(self, messageId):
        return self.talk.removeMessage(messageId)
    
    @loggedIn
    def removeAllMessages(self, lastMessageId):
        return self.talk.removeAllMessages(0, lastMessageId)

    @loggedIn
    def removeMessageFromMyHome(self, messageId):
        return self.talk.removeMessageFromMyHome(messageId)

    @loggedIn
    def destroyMessage(self, chatId, messageId):
        return self.talk.destroyMessage(0, chatId, messageId, sessionId)
    
    @loggedIn
    def sendChatChecked(self, consumer, messageId):
        return self.talk.sendChatChecked(0, consumer, messageId)

    @loggedIn
    def sendEvent(self, messageObject):
        return self.talk.sendEvent(0, messageObject)

    @loggedIn
    def getLastReadMessageIds(self, chatId):
        return self.talk.getLastReadMessageIds(0, chatId)

    @loggedIn
    def getPreviousMessagesV2WithReadCount(self, messageBoxId, endMessageId, messagesCount=50):
        return self.talk.getPreviousMessagesV2WithReadCount(messageBoxId, endMessageId, messagesCount)

    """Object"""

    @loggedIn
    def sendImage(self, to, path):
        objectId = self.sendMessage(to=to, text=None, contentType = 1).id
        return self.uploadObjTalk(path=path, type='image', returnAs='bool', objId=objectId)

    @loggedIn
    def sendImageWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendImage(to, path)

    @loggedIn
    def sendGIF(self, to, path):
        return self.uploadObjTalk(path=path, type='gif', returnAs='bool', to=to)

    @loggedIn
    def sendGIFWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendGIF(to, path)

    @loggedIn
    def sendVideo(self, to, path):
        objectId = self.sendMessage(to=to, text=None, contentMetadata={'VIDLEN': '60000','DURATION': '60000'}, contentType = 2).id
        return self.uploadObjTalk(path=path, type='video', returnAs='bool', objId=objectId)

    @loggedIn
    def sendVideoWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendVideo(to, path)

    @loggedIn
    def sendAudio(self, to, path):
        objectId = self.sendMessage(to=to, text=None, contentType = 3).id
        return self.uploadObjTalk(path=path, type='audio', returnAs='bool', objId=objectId)

    @loggedIn
    def sendAudioWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendAudio(to, path)

    """
    @loggedIn
    def sendFile(self, to, path, file_name=''):
        if file_name == '':
            file_name = ntpath.basename(path)
        file_size = len(open(path, 'rb').read())
        objectId = self.sendMessage(to=to, text=None, contentMetadata={'FILE_NAME': str(file_name),'FILE_SIZE': str(file_size)}, contentType = 14).id
        return self.uploadObjTalk(path=path, type='file', returnAs='bool', objId=objectId)

    @loggedIn
    def sendFileWithURL(self, to, url, fileName=''):
        path = self.downloadFileURL(url, 'path')
        return self.sendFile(to, path, fileName)
   """

    """Contact"""
        
    @loggedIn
    def blockContact(self, mid):
        return self.talk.blockContact(0, mid)

    @loggedIn
    def unblockContact(self, mid):
        return self.talk.unblockContact(0, mid)

    @loggedIn
    def findAndAddContactByMetaTag(self, userid, reference):
        return self.talk.findAndAddContactByMetaTag(0, userid, reference)

    @loggedIn
    def findAndAddContactsByMid(self, mid):
        return self.talk.findAndAddContactsByMid(0, mid, 0, '')

    @loggedIn
    def findAndAddContactsByEmail(self, emails=[]):
        return self.talk.findAndAddContactsByEmail(0, emails)

    @loggedIn
    def findAndAddContactsByUserid(self, userid):
        return self.talk.findAndAddContactsByUserid(0, userid)

    @loggedIn
    def findContactsByUserid(self, userid):
        return self.talk.findContactByUserid(userid)

    @loggedIn
    def findContactByTicket(self, ticketId):
        return self.talk.findContactByUserTicket(ticketId)

    @loggedIn
    def getAllContactIds(self):
        return self.talk.getAllContactIds()

    @loggedIn
    def getBlockedContactIds(self):
        return self.talk.getBlockedContactIds()

    @loggedIn
    def getContact(self, mid):
        return self.talk.getContact(mid)

    @loggedIn
    def getContacts(self, midlist):
        return self.talk.getContacts(midlist)

    @loggedIn
    def getFavoriteMids(self):
        return self.talk.getFavoriteMids()

    @loggedIn
    def getHiddenContactMids(self):
        return self.talk.getHiddenContactMids()

    @loggedIn
    def tryFriendRequest(self, midOrEMid, friendRequestParams, method=1):
        return self.talk.tryFriendRequest(midOrEMid, method, friendRequestParams)

    @loggedIn
    def makeUserAddMyselfAsContact(self, contactOwnerMid):
        return self.talk.makeUserAddMyselfAsContact(contactOwnerMid)

    @loggedIn
    def getContactWithFriendRequestStatus(self, id):
        return self.talk.getContactWithFriendRequestStatus(id)

    @loggedIn
    def reissueUserTicket(self, expirationTime=100, maxUseCount=100):
        return self.talk.reissueUserTicket(expirationTime, maxUseCount)
    
    @loggedIn
    def cloneContactProfile(self, mid):
        contact = self.getContact(mid)
        profile = self.profile
        profile.displayName = contact.displayName
        profile.statusMessage = contact.statusMessage
        profile.pictureStatus = contact.pictureStatus
        if self.getProfileCoverId(mid) is not None:
            self.updateProfileCoverById(self.getProfileCoverId(mid))
        self.updateProfileAttribute(8, profile.pictureStatus)
        return self.updateProfile(profile)

    """Group"""

    @loggedIn
    def getChatRoomAnnouncementsBulk(self, chatRoomMids):
        return self.talk.getChatRoomAnnouncementsBulk(chatRoomMids)

    @loggedIn
    def getChatRoomAnnouncements(self, chatRoomMid):
        return self.talk.getChatRoomAnnouncements(chatRoomMid)

    @loggedIn
    def createChatRoomAnnouncement(self, chatRoomMid, type, contents):
        return self.talk.createChatRoomAnnouncement(0, chatRoomMid, type, contents)

    @loggedIn
    def removeChatRoomAnnouncement(self, chatRoomMid, announcementSeq):
        return self.talk.removeChatRoomAnnouncement(0, chatRoomMid, announcementSeq)

    @loggedIn
    def getGroupWithoutMembers(self, groupId):
        return self.talk.getGroupWithoutMembers(groupId)
    
    @loggedIn
    def findGroupByTicket(self, ticketId):
        return self.talk.findGroupByTicket(ticketId)

    @loggedIn
    def acceptGroupInvitation(self, groupId):
        return self.talk.acceptGroupInvitation(0, groupId)

    @loggedIn
    def acceptGroupInvitationByTicket(self, groupId, ticketId):
        return self.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)

    @loggedIn
    def cancelGroupInvitation(self, groupId, contactIds):
        return self.talk.cancelGroupInvitation(0, groupId, contactIds)

    @loggedIn
    def createGroup(self, name, midlist):
        return self.talk.createGroup(0, name, midlist)

    @loggedIn
    def getGroup(self, groupId):
        return self.talk.getGroup(groupId)

    @loggedIn
    def getGroups(self, groupIds):
        return self.talk.getGroups(groupIds)

    @loggedIn
    def getGroupsV2(self, groupIds):
        return self.talk.getGroupsV2(groupIds)

    @loggedIn
    def getCompactGroup(self, groupId):
        return self.talk.getCompactGroup(groupId)

    @loggedIn
    def getCompactRoom(self, roomId):
        return self.talk.getCompactRoom(roomId)

    @loggedIn
    def getGroupIdsByName(self, groupName):
        gIds = []
        for gId in self.getGroupIdsJoined():
            g = self.getCompactGroup(gId)
            if groupName in g.name:
                gIds.append(gId)
        return gIds

    @loggedIn
    def getGroupIdsInvited(self):
        return self.talk.getGroupIdsInvited()

    @loggedIn
    def getGroupIdsJoined(self):
        return self.talk.getGroupIdsJoined()

    @loggedIn
    def updateGroupPreferenceAttribute(self, groupMid, updatedAttrs):
        return self.talk.updateGroupPreferenceAttribute(0, groupMid, updatedAttrs)

    @loggedIn
    def inviteIntoGroup(self, groupId, midlist):
        return self.talk.inviteIntoGroup(0, groupId, midlist)

    @loggedIn
    def kickoutFromGroup(self, groupId, midlist):
        return self.talk.kickoutFromGroup(0, groupId, midlist)

    @loggedIn
    def leaveGroup(self, groupId):
        return self.talk.leaveGroup(0, groupId)

    @loggedIn
    def rejectGroupInvitation(self, groupId):
        return self.talk.rejectGroupInvitation(0, groupId)

    @loggedIn
    def reissueGroupTicket(self, groupId):
        return self.talk.reissueGroupTicket(groupId)

    @loggedIn
    def updateGroup(self, groupObject):
        return self.talk.updateGroup(0, groupObject)

    """Room"""

    @loggedIn
    def createRoom(self, midlist):
        return self.talk.createRoom(0, midlist)

    @loggedIn
    def getRoom(self, roomId):
        return self.talk.getRoom(roomId)

    @loggedIn
    def inviteIntoRoom(self, roomId, midlist):
        return self.talk.inviteIntoRoom(0, roomId, midlist)

    @loggedIn
    def leaveRoom(self, roomId):
        return self.talk.leaveRoom(0, roomId)

    """Call"""
        
    @loggedIn
    def acquireCallTalkRoute(self, to):
        return self.talk.acquireCallRoute(to)
    
    """Report"""

    @loggedIn
    def reportSpam(self, chatMid, memberMids=[], spammerReasons=[], senderMids=[], spamMessageIds=[], spamMessages=[]):
        return self.talk.reportSpam(chatMid, memberMids, spammerReasons, senderMids, spamMessageIds, spamMessages)
        
    @loggedIn
    def reportSpammer(self, spammerMid, spammerReasons=[], spamMessageIds=[]):
        return self.talk.reportSpammer(spammerMid, spammerReasons, spamMessageIds)


    """
    RIO BOT'S
    """

    def loadData(self):
        try:
            with open('{}.json'.format(self.profile.mid),'r',encoding='utf-8') as fp:
                self.set = json.load(fp)
        except:
            os.system("cp -r %s.json %s.json"%("base", self.profile.mid))
            with open('{}.json'.format(self.profile.mid),'r',encoding='utf-8') as fp:
                self.set = json.load(fp)
            self.set["response"]["rname"] = sys.argv[0].replace(".py","") + " "
            self.set["response"]["sname"] = "x "
            self.save_set()
        with open('db.json','r',encoding='utf-8') as fp:
            self.db = json.load(fp)
        with open('antijs.json','r',encoding='utf-8') as fp:
            self.antijs = json.load(fp)
        self.scode = self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"] + self.db["bots"] + self.antijs["js"] + self.db["whitelist"]
        if self.set["start"] == None:self.set["start"] = time.time()
        self.custom_style = "「 %s 」"

    def save_db(self):
        with open('db.json','w',encoding='utf-8') as fp:
            return json.dump(self.db, fp, sort_keys=False, indent=4)

    def save_set(self):
        with open('{}.json'.format(self.profile.mid),'w',encoding='utf-8') as fp:
            return json.dump(self.set, fp, sort_keys=False, indent=4)

    def save_antijs(self):
        with open('antijs.json','w',encoding='utf-8') as fp:
            return json.dump(self.antijs, fp, sort_keys=False, indent=4)

    def command(self, text):
        msg = text.lower()
        if self.set["response"]["rname"] != "":
            if msg.startswith(self.set["response"]["rname"]):
                cmd = msg.replace(self.set["response"]["rname"],"")
            else:
                cmd = "Undefined command"
        else:
            cmd = text.lower()
        return cmd

    def squadCMD(self, text):
        msg = text.lower()
        if self.set["response"]["sname"] != "":
            if msg.startswith(self.set["response"]["sname"]):
                cmd = msg.replace(self.set["response"]["sname"],"")
            else:
                cmd = "Undefined command"
        else:
            cmd = text.lower()
        return cmd

    def simplifySplit(self, text):
        if "," in text.lower():
            xyzs = text.split(",")
            data_xyz = []
            for xyz in xyzs:
                data_xyz.append(int(xyz)-1)
            return data_xyz
        elif "-" in text.lower():
            data_xyz = []
            for xyz in range(int(text.split("-")[0]), int(text.split("-")[1])+1):
                data_xyz.append(int(xyz)-1)
            return data_xyz
        else:
            return [int(text)-1]

    def ClearRepeat(self, to):
        self.set["add_del"]["repeat"] = False
        if self.set["add_del"]["owner"]:
            self.set["add_del"]["owner"] = False
            self.sendMessage(to, "Add Owner canceled.")
        if self.set["add_del"]["admin"]:
            self.set["add_del"]["admin"] = False
            self.sendMessage(to, "Add Admin canceled.")
        if self.set["add_del"]["staff"]:
            self.set["add_del"]["staff"] = False
            self.sendMessage(to, "Add Staff canceled.")
        if self.set["add_del"]["bots"]:
            self.set["add_del"]["bots"] = False
            self.sendMessage(to, "Add Bot's canceled.")
        if self.set["add_del"]["jsbot"]:
            self.set["add_del"]["jsbot"] = False
            self.sendMessage(to, "Add Bot's canceled.")
        if self.set["add_del"]["whitelist"]:
            self.set["add_del"]["whitelist"] = False
            self.sendMessage(to, "Add Whitelist canceled.")
        if self.set["add_del"]["blacklist"]:
            self.set["add_del"]["blacklist"] = False
            self.sendMessage(to, "Add Blacklist canceled.")
        if self.set["add_del"]["expel"]:
            self.set["add_del"]["expel"] = False
            self.sendMessage(to, "Expel canceled.")

    def sendMentioncok(self, to, text="", mids=[], senderIcon="", senderName=""):
      arrData = ""
      arr = []
      mention = "@team_silent "
      if mids == []:
        raise Exception("Invalid mids")
      if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ''
        h = ''
        for mid in range(len(mids)):
            h+= str(texts[mid].encode('unicode-escape'))
            textx += str(texts[mid])
            if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 9
            else:slen = len(textx);elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
      else:
        textx = ''
        slen = len(textx)
        elen = len(textx) + 18
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
      self.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}'), 'MSG_SENDER_ICON': senderIcon, 'MSG_SENDER_NAME': senderName}, 0)

    def updatePictureAndVideo(self, pict, video):
        try:
            files = {'file': open(video, 'rb')}
            obs_params = self.genOBSParams({'oid': self.profile.mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'video.mp4'})
            data = {'params': obs_params}
            r_vp = self.server.postContent('{}/talk/vp/upload.nhn'.format(str(self.server.LINE_OBS_DOMAIN)), data=data, files=files)
            if r_vp.status_code != 201:
                return "Failed update profile"
            self.updateProfilePicture(pict, 'vp')
            return "Success update profile"
        except Exception as e:
            raise Exception("Error change video and picture profile %s"%str(e))

    def BotCommand(self, type, to):
      if type == "self":
        key = self.set["response"]["rname"]
        txt = "   ⚔️ SHADOW BOTLINE ⚔️ \n\n⚔️⚔️⚔️ KeyCommand ⚔️⚔️⚔️ \n"
        num = 0
        chatbot = ["mute","unmute","chatbot:<on/off>"]
        general = ["speed","debug","check","stats","invitebots","invitebots:qr","grouplist","ourl","curl","pendings","cancel「num」","join「url」","say「text」","creategroup「name」","@bye"]
        update = ["updatername「text」","updatesname「text」","updatename「enter|name」","updatestatus「enter|name」","updatepicture","updatedual"]
        prodemote = ["owner:<on/repeat>","admin:<on/repeat>","staff:<on/repeat>","whitelist:<on/repeat>","bots:<on/repeat>","jsbot:<on/repeat>","ban:<on/repeat>","expel:<on/repeat>","repeat:off"]
        kickinvite = ["kick <@>","invite <@>","vkick <@>"]
        protection = ["protection:<0-2>","promember:<0-2>","prolink:<0-2>","denyinvite:<0-2>","denycancel:<0-2>","namelock:<0-2>","iconlock:<0-2>","autopurge:<on/off>","antijs<on/off>","addwordban「text」","delwordban「text」","settings"]
        list = ["ownerlist","adminlist","stafflist","botlist","whitelist","blacklist","wordbanlist"]
        clear = ["clearban","clearwhitelist","clearadmin","clearstaff","clearbots","refresh","restart"]
        num = (num + 1)
        txt += "\n⚔️ Chatbot ⚔️ "
        txt += "\n   %i. rname/responsemame" % num
        num = (num + 1)
        txt += "\n   %i. sname/squadname" % num
        num = (num + 1)
        for x in chatbot:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ General ⚔️ "
        for x in general:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n</> Update"
        for x in update:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ Promotion ⚔️ "
        for x in prodemote:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ Kick & Invite ⚔️ "
        for x in kickinvite:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ Protection ⚔️ "
        for x in protection:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ List ⚔️ "
        for x in list:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ Clear ⚔️ "
        for x in clear:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        self.sendMessage(to, str(txt))
      if type == "squad":
        key = self.set["response"]["rname"]
        txt = "   ⚔️ SHADOW BOTLINE ⚔️ \n\n⚔️⚔️⚔️ KeyCommand ⚔️⚔️⚔️ \n"
        num = 0
        chatbot = ["mute","unmute","chatbot:<on/off>"]
        general = ["speed","debug","check","stats","invitebots","invitebots:qr","grouplist","ourl","curl","pendings","cancel「num」","join「url」","say「text」","creategroup「name」","@bye"]
        update = ["updatername「text」","updatesname「text」","updatename「enter|name」","updatestatus「enter|name」","updatepicture","updatedual"]
        prodemote = ["owner:<on/repeat>","admin:<on/repeat>","staff:<on/repeat>","whitelist:<on/repeat>","bots:<on/repeat>","jsbot:<on/repeat>","ban:<on/repeat>","expel:<on/repeat>","repeat:off"]
        kickinvite = ["kick <@>","invite <@>","vkick <@>"]
        protection = ["protection:<0-2>","promember:<0-2>","prolink:<0-2>","denyinvite:<0-2>","denycancel:<0-2>","namelock:<0-2>","iconlock:<0-2>","autopurge:<on/off>","antijs<on/off>","addwordban「text」","delwordban「text」","settings"]
        list = ["ownerlist","adminlist","stafflist","botlist","whitelist","blacklist","wordbanlist"]
        clear = ["clearban","clearwhitelist","clearadmin","clearstaff","clearbots","refresh","restart"]
        num = (num + 1)
        txt += "\n⚔️ Chatbot ⚔️ "
        txt += "\n   %i. rname/responsemame" % num
        num = (num + 1)
        txt += "\n   %i. sname/squadname" % num
        num = (num + 1)
        for x in chatbot:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ General ⚔️ "
        for x in general:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n</> Update"
        for x in update:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ Promotion ⚔️ "
        for x in prodemote:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ Kick & Invite ⚔️ "
        for x in kickinvite:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ Protection ⚔️ "
        for x in protection:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ List ⚔️ "
        for x in list:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        txt += "\n\n⚔️ Clear ⚔️ "
        for x in clear:txt += "\n   %i. %s%s" % (num, key, x);num = (num + 1)
        self.sendMessage(to, str(txt))

    """ ANTI JavaScript """

    def antijs_notified_kickout_from_group(self, op):
        if op.param3 in self.db["developer"] + self.db["owner"] + self.db["bots"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                try:
                    backup_js = self.db["owner"] + self.db["bots"]
                    self.acceptGroupInvitation(op.param1)
                    for xyz in backup_js:
                        if xyz != self.profile.mid:self.findAndAddContactsByMid(xyz)
                    self.inviteIntoGroup(op.param1, backup_js)
                    self.kickoutFromGroup(op.param1, [op.param2])
                except:
                    group = self.getCompactGroup(op.param1)
                    if group.preventedJoinByTicket == True:group.preventedJoinByTicket = False;self.updateGroup(group)
                    gticket = self.reissueGroupTicket(op.param1)
                    for xyz in self.db["bots"]:self.sendMessage(xyz, "defend %s|%s" % (op.param1, gticket))
                    self.sendMessage(op.param3, "Group URL : line://ti/g/%s" % gticket)
                finally:self.leaveGroup(op.param1)

    """ NOTIFIED UPDATE GROUP """

    def notified_update_group(self, op):
        if op.param3 == "1" and op.param1 in self.set["protect"]["name"]["1"]:
            if op.param2 not in self.scode:
                group = self.getCompactGroup(op.param1)
                group.name = self.set["backup"]["name"][op.param1]
                self.updateGroup(group)
                if op.param1 in self.set["protect"]["name"]["2"]:self.kickoutFromGroup(op.param1, [op.param2])
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
        if op.param3 == "2" and op.param1 in self.set["protect"]["icon"]["1"]:
            if op.param2 not in self.scode:
                self.updateGroupPicture(op.param1, self.set["backup"]["icon"][op.param1])
                if op.param1 in self.set["protect"]["icon"]["2"]:self.kickoutFromGroup(op.param1, [op.param2])
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
        if op.param3 == "4" and op.param1 in self.set["protect"]["qrcode"]["1"]:
            if op.param2 not in self.scode:
                group = self.getCompactGroup(op.param1)
                if group.preventedJoinByTicket != self.set["backup"]["qrcode"][op.param1]:group.preventedJoinByTicket = self.set["backup"]["qrcode"][op.param1];self.updateGroup(group)
                if op.param1 in self.set["protect"]["qrcode"]["2"]:self.kickoutFromGroup(op.param1, [op.param2])
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()

    """ NOTIFIED INVITE INTO GROUP """

    def notified_invite_into_group(self, op):
        if self.profile.mid in op.param3:
            if op.param2 in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"] + self.db["bots"] + self.antijs["js"]:
                self.acceptGroupInvitation(op.param1)
                group = self.getCompactGroup(op.param1)
                gMemberMid = [contact.mid for contact in group.members]
                for userban in gMemberMid:
                    if userban in self.db["blacklist"]:self.kickoutFromGroup(op.param1, [userban])
        if op.param1 not in self.set["allowban"]:
          for userban in self.db["blacklist"]:
            if userban in op.param3:
                group = self.getCompactGroup(op.param1)
                gPendingMid = [contact.mid for contact in group.invitee]
                for targets in gPendingMid:
                  if targets in self.db["blacklist"]:self.cancelGroupInvitation(op.param1, [targets])
                if op.param2 not in self.scode:
                  if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                  self.kickoutFromGroup(op.param1, [op.param2])
                else:self.sendMessage(op.param1, "Can't invite blacklist user!")
        if op.param1 in self.set["protect"]["invite"]["1"]:
            if op.param2 not in self.scode:
                group = self.getCompactGroup(op.param1)
                gPendingMid = [contact.mid for contact in group.invitee]
                for targets in gPendingMid:
                    if targets in op.param3:self.cancelGroupInvitation(op.param1, [targets])
                if op.param1 in self.set["protect"]["invite"]["2"]:
                    if op.param2 not in self.db["blacklist"]:
                        self.db["blacklist"].append(op.param2)
                        self.save_db()
                    self.kickoutFromGroup(op.param1, [op.param2])

    """ NOTIFIED_LEAVE_GROUP """
    
    def notified_leave_group(self, op):
        if op.param2 in self.antijs["js"] and op.param1 in self.antijs["group"]:self.findAndAddContactsByMid(op.param2);self.inviteIntoGroup(op.param1, [op.param2])

    """ NOTIFIED ACCEPT GROUP INVITATION """

    def notified_accept_group_invitation(self, op):
        if op.param2 in self.db["blacklist"]:
            self.kickoutFromGroup(op.param1, [op.param2])
        if op.param1 in self.set["protect"]["join"]:
            if op.param2 not in self.scode:
                self.kickoutFromGroup(op.param1, [op.param2])

    """ NOTIFIED KICKOUT FROM GROUP """

    def notified_kickout_from_group(self, op):
        if op.param3 in self.db["bots"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"] + self.db["bots"] + self.antijs["js"]:
                group = self.getCompactGroup(op.param1)
                try:
                    self.inviteIntoGroup(op.param1,self.db["bots"])
                    self.kickoutFromGroup(op.param1, [op.param2])
                except:
                    if group.preventedJoinByTicket == True:
                        group.preventedJoinByTicket = False
                        self.updateGroup(group)
                    gticket = self.reissueGroupTicket(op.param1)
                    self.sendMessage(op.param3, "defend %s|%s" % (op.param1, gticket))
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
        if op.param3 in self.antijs["js"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param3 in self.db["staff"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param3 in self.db["admin"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param3 in self.db["owner"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param3 in self.db["developer"]:
            if op.param2 not in self.db["developer"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param3 in self.db["whitelist"]:
            if op.param2 not in self.scode:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param1 in self.set["protect"]["kick"]["1"]:
            if op.param2 not in self.scode:
                self.kickoutFromGroup(op.param1, [op.param2])
                group = self.getCompactGroup(op.param1)
                if group.preventedJoinByTicket == False:
                   group.preventedJoinByTicket = True
                   self.updateGroup(group)
                   self.db["blacklist"].append(op.param2)
                   self.save_db()
                if op.param1 in self.set["protect"]["kick"]["2"]:
                    if op.param2 not in self.db["blacklist"]:
                        self.db["blacklist"].append(op.param2)
                        self.save_db()
                        self.kickoutFromGroup(op.param1, [op.param2])

    """ NOTIFIED CANCEL INVITATION GROUP """

    def notified_cancel_invitation_group(self, op):
        if op.param3 in self.db["bots"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"] + self.db["bots"] + self.antijs["js"]:
                group = self.getCompactGroup(op.param1)
                try:
                    self.inviteIntoGroup(op.param1, [op.param3])
                    self.kickoutFromGroup(op.param1, [op.param2])
                except:
                    if group.preventedJoinByTicket == True:
                        group.preventedJoinByTicket = False
                        self.updateGroup(group)
                    gticket = self.reissueGroupTicket(op.param1)
                    self.sendMessage(op.param3, "defend %s|%s" % (op.param1, gticket))
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
        if op.param3 in self.antijs["js"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param3 in self.db["staff"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param3 in self.db["admin"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param3 in self.db["owner"]:
            if op.param2 not in self.db["developer"] + self.db["owner"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param3 in self.db["developer"]:
            if op.param2 not in self.db["developer"] + self.db["bots"] + self.antijs["js"]:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param3 in self.db["whitelist"]:
            if op.param2 not in self.scode:
                if op.param2 not in self.db["blacklist"]:
                    self.db["blacklist"].append(op.param2)
                    self.save_db()
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                self.kickoutFromGroup(op.param1, [op.param2])
        if op.param1 in self.set["protect"]["cancel"]["1"]:
            if op.param2 not in self.scode:
                self.findAndAddContactsByMid(op.param3)
                self.inviteIntoGroup(op.param1, [op.param3])
                if op.param1 in self.set["protect"]["cancel"]["2"]:
                    if op.param2 not in self.db["blacklist"]:
                        self.db["blacklist"].append(op.param2)
                        self.save_db()
                    self.kickoutFromGroup(op.param1, [op.param2])

    """Leave Room"""

    @loggedIn
    def leave_room(self, to):
        return self.leaveRoom(to)

    """ RECEIVE MESSAGE """

    def receive_message(self, op):
        rname = self.set["response"]["rname"]
        sname = self.set["response"]["sname"]
        msg = op.message
        text = str(msg.text)
        sender = msg._from
        receiver = msg.to
        developer = sender in self.db["developer"] + self.db["owner"]
        admin = sender in self.db["developer"] + self.db["owner"] + self.db["admin"]
        staff = sender in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"]
        if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
            if msg.toType == 0:
                if sender != self.profile.mid:to = sender
                else:to = receiver
            if msg.toType == 1:to = receiver
            if msg.toType == 2:to = receiver
            if msg.contentType == 0:
                if text is None:return
                else:
                    if msg.toType == 2 and sender not in self.scode:
                        for xyz_wordban in self.set["protect"]["wordban"]["list"]:
                            if xyz_wordban in text.lower():self.sendMention(to, "@!, wordban detected!", [sender]);self.kickoutFromGroup(to, [sender])
                    cmds = self.command(text)
                    squads = self.squadCMD(text)
                for cmd in cmds.split(' & '):
                  for squad in squads.split(' & '):
                    if sender in self.db["bots"]:

                        if text.lower().startswith("defend"):
                            txt = text.replace(text[:7],"")
                            spl = txt.split("|")
                            self.acceptGroupInvitationByTicket(spl[0], spl[1])
                            group = self.getCompactGroup(spl[0])
                            gMemberMid = [contact.mid for contact in group.members]
                            for userban in gMemberMid:
                                if userban in self.db["blacklist"]:self.kickoutFromGroup(spl[0], [userban])

                    if staff:
                        """ CHATBOT """
                        if text.lower() in ["rname","responsename"]:self.sendMessage(to, self.set["response"]["rname"])
                        if text.lower() in ["sname","squadname"]:self.sendMessage(to, self.set["response"]["sname"])
                        if developer:
                            if cmd.startswith("updatername"):
                                txt = text.replace(text[:len(rname)+12],"")
                                self.sendMessage(to, "Response Name update to [ %s ] From [ %s ]" % (txt, rname))
                                self.set["response"]["rname"] = txt
                            if squad.startswith("updatesname"):
                                txt = text.replace(text[:len(sname)+12],"")
                                self.sendMessage(to, "Squad Name update to [ %s ] From [ %s ]" % (txt, sname))
                                self.set["response"]["sname"] = txt
                            if text.lower().startswith(rname + "exec\n"):
                                exec(text[len(rname + "exec\n"):])
                                self.sendMessage(self.db["developer"][0], "{}, has been executed command\n\n{}".format(self.getContact(sender).displayName, text[len(rname + "exec\n"):]))

                        if to not in self.set["chatbot"]:
                            if cmd == "chatbot:on" or squad == "chatbot:on":
                                self.set["chatbot"].append(to)
                                self.save_set()
                                self.sendMessage(to, "Switched to chatbot mode.")
                        if to in self.set["chatbot"]:
                            if cmd == "chatbot:off" or squad == "chatbot:off":
                                if to in self.set["chatbot"]:
                                    self.set["chatbot"].remove(to)
                                    self.save_set()
                                    self.sendMessage(to, "I'll be here when you need me.")
                        if to not in self.set["response"]["chatbot"]:
                            if cmd == "bot:on" or squad == "bot:on":
                                self.set["response"]["chatbot"].append(to)
                                self.save_set()
                                self.sendMessage(to, "Switched to normal mode.")
                        if to in self.set["response"]["chatbot"]:
                            if cmd == "mute" or squad == "mute":
                                if to in self.set["response"]["chatbot"]:
                                    self.set["response"]["chatbot"].remove(to)
                                    self.save_set()
                                    self.sendMessage(to, "I'll be here when you need me.")

                            """ JOIN WITH QR """
                            if cmd.startswith("join "):
                                txt = text.replace(text[:len(rname)+5],"")
                                link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                links = link_re.findall(txt)
                                n_links = []
                                for l in links:
                                    if l not in n_links:
                                        n_links.append(l)
                                for ticket_id in n_links:
                                    group = self.findGroupByTicket(ticket_id)
                                    self.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    self.sendMessage(to, "Success joined : %s" % group.name)
                            if squad.startswith("join "):
                                txt = text.replace(text[:len(sname)+5],"")
                                link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                links = link_re.findall(txt)
                                n_links = []
                                for l in links:
                                    if l not in n_links:
                                        n_links.append(l)
                                for ticket_id in n_links:
                                    group = self.findGroupByTicket(ticket_id)
                                    self.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    self.sendMessage(to, "Success joined : %s" % group.name)
                            if cmd == "help":self.BotCommand("self", to)
                            if squad == "help":self.BotCommand("squad", to)

                            """ CHAT RELATED """
                            if msg.toType == 2:
                                if cmd == "settings" or squad == "settings":
                                    txt = "   SETTING'S PROTECTION\n ╭──────────────"
                                    txt += "\n ├> Rname : %s" % self.set["response"]["rname"]
                                    txt += "\n ├> Sname : %s" % self.set["response"]["sname"]
                                    txt += "\n ├> Group : %s\n ├──────────────" % self.getCompactGroup(to).name
                                    if to in self.set["protect"]["kick"]["1"]:txt += "\n ├> Pro Kick : On"
                                    else:txt += "\n ├> Pro Kick : Off"
                                    if to in self.set["protect"]["invite"]["1"]:txt += "\n ├> Pro Invite : On"
                                    else:txt += "\n ├> Pro Invite : Off"
                                    if to in self.set["protect"]["cancel"]["1"]:txt += "\n ├> Pro Cancel : On"
                                    else:txt += "\n ├> Pro Cancel : Off"
                                    if to in self.set["protect"]["join"]:txt += "\n ├> Auto Purge : On"
                                    else:txt += "\n ├> Auto Purge : Off"
                                    if to in self.set["protect"]["qrcode"]["1"]:txt += "\n ├> Pro QR : On"
                                    else:txt += "\n ├> Pro QR : Off"
                                    if to in self.set["protect"]["name"]["1"]:txt += "\n ├> Kunci Name Grup: On"
                                    else:txt += "\n ├> Kunci Name Grup: Off"
                                    if to in self.set["protect"]["icon"]["1"]:txt += "\n ├> kunci Picture Grup: On"
                                    else:txt += "\n ├> Kunci picture Grup: Off"
                                    if to in self.antijs["group"]:txt += "\n ├> Anti JS : On\n ╰───⟦􏿿􏿿􏿿􏿿􏿿BOTS ™⟧"
                                    else:txt += "\n ├> Anti JS : Off\n ╰───⟦􏿿􏿿􏿿􏿿􏿿BOTS™⟧"
                                    self.sendMessage(to, str(txt))
                                if cmd == "check" or squad == "check":
                                    status = {"kick": "", "invite": "", "cancel": ""}
                                    txt = "   🛠️ Bot's Status 🛠️\n╭─────────>"
                                    try:self.kickoutFromGroup(to, ["ub1fb6f70aa74ae8547fb577f5613d285"]);status["kick"] = "Ready"
                                    except:status["kick"] = "Limit"
                                    try:self.inviteIntoGroup(to, ["ub1fb6f70aa74ae8547fb577f5613d285"]);status["invite"] = "Ready"
                                    except:status["invite"] = "Limit"
                                    try:self.cancelGroupInvitation(to, ["ub1fb6f70aa74ae8547fb577f5613d285"]);status["cancel"] = "Ready"
                                    except:status["cancel"] = "Limit"
                                    txt += "\n├「Kick : %s」" % status["kick"]
                                    txt += "\n├「Invite : %s」" % status["invite"]
                                    txt += "\n├「Cancel : %s」\n╰─────────>" % status["cancel"]
                                    self.sendMessage(to, str(txt))
                                if cmd == "test" or squad == "test":
                                    status = "{}"
                                    try:self.kickoutFromGroup(to, [self.profile.mid]);status = "Ready."
                                    except:status = "Limit."
                                    self.sendMessage(to, str(status))
                            if msg.toType == 2:
                                if cmd == "debug" or squad == "debug":get_profile_time_start = time.time();get_profile = self.getProfile();get_profile_time = time.time() - get_profile_time_start;get_group_time_start = time.time();get_group = self.getCompactGroup(to);get_group_time = time.time() - get_group_time_start;get_contact_time_start = time.time();get_contact = self.getContact(get_profile.mid);get_contact_time = time.time() - get_contact_time_start;elapsed_time = time.time() - get_profile_time_start;self.sendMessage(to, " 「 Debuging 」\n - Send Message\n   %.5f\n - Get Profile\n   %.5f\n - Get Contact\n   %.5f\n - Get Group\n   %.5f" % (elapsed_time,get_profile_time,get_contact_time,get_group_time))
                            if cmd == "stats" or squad == "stats":timeNow = time.time();runtime = timeNow - int(self.set["start"]);runtime = format_timespan(runtime);self.sendMessage(to, "Time to due : %s" % runtime)
                            if cmd == "grouplist" or squad == "grouplist":
                                groups = self.getGroupIdsJoined();txt = "「 Group List 」";num = 0
                                for gid in groups:group = self.getGroup(gid);txt += "\n%i. %s | ( %s )" % (num, group.name, len(group.members));num += 1
                                self.sendMessage(to, str(txt))
                            if cmd == "ourl" or squad == "ourl":
                                group = self.getCompactGroup(to)
                                if group.preventedJoinByTicket != False:group.preventedJoinByTicket = False;self.updateGroup(group)
                                if msg.toType == 0:self.sendMessage(sender, "Group URL : line://ti/g/%s"%self.reissueGroupTicket(to))
                                if msg.toType == 2:self.sendMessage(msg.to, "Group URL : line://ti/g/%s"%self.reissueGroupTicket(to))
                            if cmd == "curl" or squad == "curl":
                                group = self.getCompactGroup(to)
                                if group.preventedJoinByTicket != True:
                                    group.preventedJoinByTicket = True
                                    self.updateGroup(group)
                                    self.sendMessage(to, "Group QR has been disabled.")
                                else:
                                    self.sendMessage(to, "Group QR already disabled.")
                            if cmd.startswith("say"):self.sendMessage(to, text.replace(text[:len(rname) + 4],""))
                            if squad.startswith("say"):self.sendMessage(to, text.replace(text[:len(sname) + 4],""))
                            if cmd.startswith("creategroup"):
                                txt = text.replace(text[:len(rname) + 12],"");self.createGroup(txt, [self.profile.mid]);gids = self.getGroupIdsByName(txt)
                                for gid in gids:
                                    try:
                                        x = self.getGroup(gid)
                                        x.preventedJoinByTicket = False
                                        self.updateGroup(x)
                                        gticket = self.reissueGroupTicket(x.id)
                                        self.sendMessage(to, "「 Create Group 」\n • Name : %s\n • QR : http://line.me/R/ti/g/%s" % (txt, gticket))
                                        for xyz in self.db["bots"]:
                                            if self.profile.mid not in xyz:
                                                self.sendMessage(xyz, "defend %s|%s" % (gid, gticket))
                                    except Exception as e:self.sendMessage(to, str(e))
                            if squad.startswith("creategroup"):
                                txt = text.replace(text[:len(sname) + 12],"");self.createGroup(txt, [self.profile.mid]);gids = self.getGroupIdsByName(txt)
                                for gid in gids:
                                    try:
                                        x = self.getGroup(gid)
                                        x.preventedJoinByTicket = False
                                        self.updateGroup(x)
                                        gticket = self.reissueGroupTicket(x.id)
                                        self.sendMessage(to, "「 Create Group 」\n • Name : %s\n • QR : http://line.me/R/ti/g/%s" % (txt, gticket))
                                        for xyz in self.db["bots"]:
                                            if self.profile.mid not in xyz:
                                                self.sendMessage(xyz, "defend %s|%s" % (gid, gticket))
                                    except Exception as e:self.sendMessage(to, str(e))
                            if msg.toType == 2:
                                if cmd == "invitebots" or squad == "invitebots":
                                    for xyz in self.db["bots"]:
                                        if self.profile.mid not in xyz:self.findAndAddContactsByMid(xyz)
                                    self.inviteIntoGroup(to, self.db["bots"])
                                if cmd == "invitebots:qr" or squad == "invitebots:qr":
                                    group = self.getCompactGroup(to)
                                    if group.preventedJoinByTicket == True:group.preventedJoinByTicket = False;self.updateGroup(group)
                                    gticket = self.reissueGroupTicket(to)
                                    for xyz in self.db["bots"]:
                                        if self.profile.mid not in xyz:self.sendMessage(xyz, "defend %s|%s" % (to, gticket))
                                if sender in self.db["developer"]:
                                    if cmd == "inviteme" or squad == "inviteme":
                                        if self.profile.mid not in sender:self.findAndAddContactsByMid(sender)
                                        self.inviteIntoGroup(to, [sender])
                                    if cmd == "groupinfo" or squad == "groupinfo":
                                        group = self.getCompactGroup(to)
                                        txt = self.custom_style % "Group Info"
                                        txt += "\n • Group ID : %s" % to
                                        txt += "\n • Name : %s" % group.name
                                        if group.preventedJoinByTicket != True:txt += "\n • Ticket : %s" % str(self.reissueGroupTicket(group.id))
                                        self.sendMessage(msg.to, str(txt))
                                if cmd == "@bye" or squad == "@bye":
                                    self.sendMessage(to, "Bye - bye %s" % self.getCompactGroup(to).name)
                                    self.leaveGroup(to)
                            if sender in self.db["developer"]:
                                if cmd == "@byeall" or squad == "@byeall":
                                    group = self.getGroupIdsJoined()
                                    for gid in group:
                                        self.sendMessage(gid, "Bye - bye %s" % self.getCompactGroup(gid).name)
                                        self.leaveGroup(gid)

                            """ LIST """
                            if cmd == "ownerlist" or squad == "ownerlist":
                                if len(self.db["owner"]) > 0:
                                    self.newMention(to, "Owner List", self.db["owner"])
                                else:
                                    self.sendMessage(to, "Ownerlist is empty.")
                            if cmd == "ownercontact" or squad == "ownercontact":
                                if len(self.db["owner"]) == 0:
                                    self.sendMessage(msg.to,"Ownerlist is empty.")
                                else:
                                    h = ""
                                    for i in self.db["owner"]:
                                          self.sendContact(msg.to, i)
                            if cmd == "adminlist" or squad == "adminlist":
                                if len(self.db["admin"]) > 0:
                                    self.newMention(to, "Admin List", self.db["admin"])
                                else:
                                    self.sendMessage(to, "Adminlist is empty.")

                            if cmd == "admincontact" or squad == "admincontact":
                                if len(self.db["admin"]) == 0:
                                    self.sendMessage(msg.to,"Adminlist is empty.")
                                else:
                                    h = ""
                                    for i in self.db["admin"]:
                                          self.sendContact(msg.to, i)
                            if cmd == "stafflist" or squad == "stafflist":
                                if len(self.db["staff"]) > 0:
                                    self.newMention(to, "Staff List", self.db["staff"])
                                else:
                                    self.sendMessage(to, "Stafflist is empty.")
                            if cmd == "staffcontact" or squad == "staffcontact":
                                if len(self.db["staff"]) == 0:
                                    self.sendMessage(msg.to,"Stafflist is empty.")
                                else:
                                    h = ""
                                    for i in self.db["staff"]:
                                          self.sendContact(msg.to, i)
                            if cmd == "whitelist" or squad == "whitelist":
                                if len(self.db["whitelist"]) > 0:
                                    self.newMention(to, "White List", self.db["whitelist"])
                                else:
                                    self.sendMessage(to, "Whitelist is empty.")
                            if cmd == "botlist" or squad == "botlist":
                                if len(self.db["bots"]) > 0:
                                    self.newMention(to, "Bot's List", self.db["bots"])
                                else:
                                    self.sendMessage(to, "Bot's list is empty.")
                            if cmd == "blacklist" or squad == "blacklist":
                                if len(self.db["blacklist"]) > 0:
                                    self.newMention(to, "Black List", self.db["blacklist"])
                                else:
                                    self.sendMessage(to, "Blacklist is empty.")
                            if cmd == "wordbanlist" or squad == "wordbanlist":
                                if len(self.set["protect"]["wordban"]["list"]) > 0:
                                    txt = self.custom_style % "Wordban List"
                                    num = 1
                                    for xyzs in self.set["protect"]["wordban"]["list"]:
                                        txt += "\n %i. %s" % (num, xyzs)
                                        num += 1
                                    self.sendMessage(to, str(txt))
                                else:
                                    self.sendMessage(to, "Wordban list is empty.")

                            if squad.startswith("jumpme "):
                                  text = squad.split()
                                  number = text[1]
                                  if number.isdigit():
                                     groups = self.getGroupIdsJoined()
                                     if int(number) < len(groups) and int(number) >= 0:
                                        groupid = groups[int(number)]
                                        try:
                                            self.findAndAddContactsByMid(sender)
                                            self.inviteIntoGroup(groupid,[sender])
                                            groupname = self.getGroup(groupid).name
                                            self.sendMessage(to,"Successfully invite to %s"%groupname)
                                        except:
                                            self.sendMessage(to,"Im not There")

                            if cmd.startswith("jumpme "):
                                  text = cmd.split()
                                  number = text[1]
                                  if number.isdigit():
                                     groups = self.getGroupIdsJoined()
                                     if int(number) < len(groups) and int(number) >= 0:
                                        groupid = groups[int(number)]
                                        try:
                                            self.findAndAddContactsByMid(sender)
                                            self.inviteIntoGroup(groupid,[sender])
                                            groupname = self.getGroup(groupid).name
                                            self.sendMessage(to,"Successfully invite to %s"%groupname)
                                        except:
                                            self.sendMessage(to,"Im not There")

                            if squad.startswith("blacklistdel "):
                                sep = squad.split(" ")
                                query = squad.replace(sep[0] + " ","")
                                aa = [a for a in self.db["blacklist"]]
                                try:
                                    listContact = aa[int(query)-1]
                                    if listContact in self.db["blacklist"]:
                                        self.db["blacklist"].remove(listContact)
                                        self.sendMention(to, "@!, Deleted from blacklist.", [listContact])
                                    else:
                                        self.sendMessage(to,"not in blacklist")
                                except Exception as e:
                                    self.sendMessage(msg.to,str(e))

                            if cmd.startswith("blacklistdel "):
                                sep = cmd.split(" ")
                                query = cmd.replace(sep[0] + " ","")
                                aa = [a for a in self.db["blacklist"]]
                                try:
                                    listContact = aa[int(query)-1]
                                    if listContact in self.db["blacklist"]:
                                        self.db["blacklist"].remove(listContact)
                                        self.sendMention(to, "@!, Deleted from blacklist.", [listContact])
                                    else:
                                        self.sendMessage(to,"not in blacklist")
                                except Exception as e:
                                    self.sendMessage(msg.to,str(e))

                            if squad.startswith("ownerdel "):
                                sep = squad.split(" ")
                                query = squad.replace(sep[0] + " ","")
                                aa = [a for a in self.db["owner"]]
                                try:
                                    listContact = aa[int(query)-1]
                                    if listContact in self.db["owner"]:
                                        self.db["owner"].remove(listContact)
                                        self.sendMention(to, "@!, Deleted from Owner.", [listContact])
                                    else:
                                        self.sendMessage(to,"not in Owner")
                                except Exception as e:
                                    self.sendMessage(msg.to,str(e))

                            if cmd.startswith("ownerdel "):
                                sep = cmd.split(" ")
                                query = cmd.replace(sep[0] + " ","")
                                aa = [a for a in self.db["owner"]]
                                try:
                                    listContact = aa[int(query)-1]
                                    if listContact in self.db["owner"]:
                                        self.db["owner"].remove(listContact)
                                        self.sendMention(to, "@!, Deleted from Owner.", [listContact])
                                    else:
                                        self.sendMessage(to,"not in owner")
                                except Exception as e:
                                    self.sendMessage(msg.to,str(e))

                            if squad.startswith("admindel "):
                                sep = squad.split(" ")
                                query = squad.replace(sep[0] + " ","")
                                aa = [a for a in self.db["admin"]]
                                try:
                                    listContact = aa[int(query)-1]
                                    if listContact in self.db["admin"]:
                                        self.db["admin"].remove(listContact)
                                        self.sendMention(to, "@!, Deleted from Admin.", [listContact])
                                    else:
                                        self.sendMessage(to,"not in Admin")
                                except Exception as e:
                                    self.sendMessage(msg.to,str(e))

                            if cmd.startswith("admindel "):
                                sep = cmd.split(" ")
                                query = cmd.replace(sep[0] + " ","")
                                aa = [a for a in self.db["admin"]]
                                try:
                                    listContact = aa[int(query)-1]
                                    if listContact in self.db["admin"]:
                                        self.db["admin"].remove(listContact)
                                        self.sendMention(to, "@!, Deleted from Admin.", [listContact])
                                    else:
                                        self.sendMessage(to,"not in Admin")
                                except Exception as e:
                                    self.sendMessage(msg.to,str(e))

                            if squad.startswith("staffdel "):
                                sep = squad.split(" ")
                                query = squad.replace(sep[0] + " ","")
                                aa = [a for a in self.db["staff"]]
                                try:
                                    listContact = aa[int(query)-1]
                                    if listContact in self.db["staff"]:
                                        self.db["staff"].remove(listContact)
                                        self.sendMention(to, "@!, Deleted from Staff.", [listContact])
                                    else:
                                        self.sendMessage(to,"not in Staff")
                                except Exception as e:
                                    self.sendMessage(msg.to,str(e))

                            if cmd.startswith("staffdel "):
                                sep = cmd.split(" ")
                                query = cmd.replace(sep[0] + " ","")
                                aa = [a for a in self.db["staff"]]
                                try:
                                    listContact = aa[int(query)-1]
                                    if listContact in self.db["staff"]:
                                        self.db["staff"].remove(listContact)
                                        self.sendMention(to, "@!, Deleted from Staff.", [listContact])
                                    else:
                                        self.sendMessage(to,"not in Staff")
                                except Exception as e:
                                    self.sendMessage(msg.to,str(e))

                    if to in self.set["response"]["chatbot"]:
                        """ Promote & Demote """
                        if sender in self.db["developer"]:
                            if cmd.startswith("owner:") or squad.startswith("owner:"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    if cmd.startswith("owner:on") or squad.startswith("owner:on"):
                                        targets = []
                                        key = eval(msg.contentMetadata["MENTION"])
                                        for x in key["MENTIONEES"]:targets.append(x["M"])
                                        for mention in targets:
                                            if mention in self.db["developer"]:
                                                self.sendMessage(to, "Can't Demote from Developer to Owner!")
                                            elif mention in self.db["owner"]:
                                                self.sendMention(to, "@!, is already in Owner.", [mention])
                                            elif mention in self.db["admin"]:
                                                self.db["admin"].remove(mention)
                                                self.db["owner"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Admin to Owner.", [mention])
                                            elif mention in self.db["staff"]:
                                                self.db["staff"].remove(mention)
                                                self.db["owner"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Staff to Owner.", [mention])
                                            elif mention in self.db["whitelist"]:
                                                self.db["whitelist"].remove(mention)
                                                self.db["owner"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Whitelist to Owner.", [mention])
                                            elif mention in self.db["bots"]:
                                                self.db["bots"].remove(mention)
                                                self.db["owner"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Bot's to Owner.", [mention])
                                            elif mention in self.db["blacklist"]:
                                                self.db["blacklist"].remove(mention)
                                                self.db["owner"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Blacklist to Owner.", [mention])
                                            else:
                                                self.db["owner"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted to Owner.", [mention])
                                            self.save_db()
                                else:
                                    if cmd[6:] == "on" or squad[6:] == "on":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["owner"] = True
                                        self.set["add_del"]["repeat"] = False
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Owner.")
                                    if cmd[6:] == "repeat" or squad[6:] == "repeat":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["owner"] = True
                                        self.set["add_del"]["repeat"] = True
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Owner.")
                        if developer:
                            if cmd.startswith("admin:") or squad.startswith("admin:"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    if cmd.startswith("admin:on") or squad.startswith("admin:on"):
                                        targets = []
                                        key = eval(msg.contentMetadata["MENTION"])
                                        for x in key["MENTIONEES"]:targets.append(x["M"])
                                        for mention in targets:
                                            if mention in self.db["developer"]:
                                                self.sendMessage(to, "Can't Demote from Developer to Admin!")
                                            elif mention in self.db["owner"]:
                                                if sender in self.db["developer"]:
                                                    self.db["owner"].remove(mention)
                                                    self.db["admin"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Owner to Admin.", [mention])
                                            elif mention in self.db["admin"]:
                                                self.sendMention(to, "@!, is already in Admin.", [mention])
                                            elif mention in self.db["staff"]:
                                                self.db["staff"].remove(mention)
                                                self.db["admin"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Staff to Admin.", [mention])
                                            elif mention in self.db["whitelist"]:
                                                self.db["whitelist"].remove(mention)
                                                self.db["admin"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Whitelist to Admin.", [mention])
                                            elif mention in self.db["bots"]:
                                                self.db["bots"].remove(mention)
                                                self.db["admin"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Bot's to Admin.", [mention])
                                            elif mention in self.db["blacklist"]:
                                                self.db["blacklist"].remove(mention)
                                                self.db["admin"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Blacklist to Admin.", [mention])
                                            else:
                                                self.db["admin"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted to Admin.", [mention])
                                            self.save_db()
                                else:
                                    if cmd[6:] == "on" or squad[6:] == "on":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["admin"] = True
                                        self.set["add_del"]["repeat"] = False
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Admin.")
                                    if cmd[6:] == "repeat" or squad[6:] == "repeat":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["admin"] = True
                                        self.set["add_del"]["repeat"] = True
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Admin.")

                        if admin:
                            if cmd.startswith("staff:") or squad.startswith("staff:"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    if cmd.startswith("staff:on") or squad.startswith("staff:on"):
                                        targets = []
                                        key = eval(msg.contentMetadata["MENTION"])
                                        for x in key["MENTIONEES"]:targets.append(x["M"])
                                        for mention in targets:
                                            if mention in self.db["developer"]:
                                                self.sendMessage(to, "Can't Demote from Developer to Staff!")
                                            elif mention in self.db["owner"]:
                                                if sender in self.db["developer"]:
                                                    self.db["owner"].remove(mention)
                                                    self.db["staff"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Owner to Staff.", [mention])
                                            elif mention in self.db["admin"]:
                                                if developer:
                                                    self.db["admin"].remove(mention)
                                                    self.db["staff"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Admin to Staff.", [mention])
                                            elif mention in self.db["staff"]:
                                                self.sendMention(to, "@!, is already in Staff.", [mention])
                                            elif mention in self.db["whitelist"]:
                                                self.db["whitelist"].remove(mention)
                                                self.db["staff"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Whitelist to Staff.", [mention])
                                            elif mention in self.db["bots"]:
                                                self.db["bots"].remove(mention)
                                                self.db["staff"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Bot's to Staff.", [mention])
                                            elif mention in self.db["blacklist"]:
                                                self.db["blacklist"].remove(mention)
                                                self.db["staff"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Blacklist to Staff.", [mention])
                                            else:
                                                self.db["staff"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted to Staff.", [mention])
                                            self.save_db()
                                else:
                                    if cmd[6:] == "on" or squad[6:] == "on":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["staff"] = True
                                        self.set["add_del"]["repeat"] = False
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Staff.")
                                    if cmd[6:] == "repeat" or squad[6:] == "repeat":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["staff"] = True
                                        self.set["add_del"]["repeat"] = True
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Staff.")
                        if staff:
                            if cmd.startswith("whitelist:") or squad.startswith("whitelist:"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    if cmd.startswith("whitelist:on") or squad.startswith("whitelist:on"):
                                        targets = []
                                        key = eval(msg.contentMetadata["MENTION"])
                                        for x in key["MENTIONEES"]:targets.append(x["M"])
                                        for mention in targets:
                                            if mention in self.db["developer"]:
                                                self.sendMessage(to, "Can't Demote from Developer to Whitelist!")
                                            elif mention in self.db["owner"]:
                                                if sender in self.db["developer"]:
                                                    self.db["owner"].remove(mention)
                                                    self.db["whitelist"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Owner to Whitelist.", [mention])
                                            elif mention in self.db["admin"]:
                                                if developer:
                                                    self.db["admin"].remove(mention)
                                                    self.db["whitelist"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Admin to Whitelist.", [mention])
                                            elif mention in self.db["staff"]:
                                                if admin:
                                                    self.db["staff"].remove(mention)
                                                    self.db["whitelist"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Staff to Whitelist.", [mention])
                                            elif mention in self.db["whitelist"]:
                                                self.sendMention(to, "@!, is already in Whitelist.", [mention])
                                            elif mention in self.db["bots"]:
                                                self.db["bots"].remove(mention)
                                                self.db["whitelist"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Bot's to Whitelist.", [mention])
                                            elif mention in self.db["blacklist"]:
                                                self.db["blacklist"].remove(mention)
                                                self.db["whitelist"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Blacklist to Whitelist.", [mention])
                                            else:
                                                self.db["whitelist"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted to Whitelist.", [mention])
                                            self.save_db()
                                else:
                                    if cmd[10:] == "on" or squad[10:] == "on":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["whitelist"] = True
                                        self.set["add_del"]["repeat"] = False
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Whitelist.")
                                    if cmd[10:] == "repeat" or squad[10:] == "repeat":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["whitelist"] = True
                                        self.set["add_del"]["repeat"] = True
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Whitelist.")
                            if cmd.startswith("bots:") or squad.startswith("bots:"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    if cmd.startswith("bots:on") or squad.startswith("bots:on"):
                                        targets = []
                                        key = eval(msg.contentMetadata["MENTION"])
                                        for x in key["MENTIONEES"]:targets.append(x["M"])
                                        for mention in targets:
                                            if mention in self.db["developer"]:
                                                self.sendMessage(to, "Can't Demote from Developer to Bot's!")
                                            elif mention in self.db["owner"]:
                                                if sender in self.db["developer"]:
                                                    self.db["owner"].remove(mention)
                                                    self.db["bots"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Owner to Bot's.", [mention])
                                            elif mention in self.db["admin"]:
                                                if developer:
                                                    self.db["admin"].remove(mention)
                                                    self.db["bots"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Admin to Bot's.", [mention])
                                            elif mention in self.db["staff"]:
                                                if admin:
                                                    self.db["staff"].remove(mention)
                                                    self.db["bots"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Staff to Bot's.", [mention])
                                            elif mention in self.db["whitelist"]:
                                                self.db["whitelist"].remove(mention)
                                                self.db["bots"].append(mention)
                                                self.sendMention(to, "@!, has been Demoted from Whitelist to Bot's.", [mention])
                                            elif mention in self.db["bots"]:
                                                self.sendMention(to, "@!, is already in Bot's.", [mention])
                                            elif mention in self.db["blacklist"]:
                                                self.db["blacklist"].remove(mention)
                                                self.db["bots"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Blacklist to Bot's.", [mention])
                                            else:
                                                self.db["bots"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted to Bot's.", [mention])
                                            self.save_db()
                                else:
                                    if cmd[5:] == "on" or squad[5:] == "on":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["bots"] = True
                                        self.set["add_del"]["repeat"] = False
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Bot's.")
                                    if cmd[5:] == "repeat" or squad[5:] == "repeat":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["bots"] = True
                                        self.set["add_del"]["repeat"] = True
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Bot's.")
                            if cmd.startswith("jsbot:") or squad.startswith("jsbot:"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    if cmd.startswith("jsbot:on") or squad.startswith("jsbot:on"):
                                        targets = []
                                        key = eval(msg.contentMetadata["MENTION"])
                                        for x in key["MENTIONEES"]:targets.append(x["M"])
                                        for mention in targets:
                                            if mention in self.db["developer"]:
                                                self.sendMessage(to, "Can't Demote from Developer to Bot's!")
                                            elif mention in self.db["owner"]:
                                                if sender in self.db["developer"]:
                                                    self.db["owner"].remove(mention)
                                                    self.antijs["js"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Owner to Bot's.", [mention])
                                            elif mention in self.db["admin"]:
                                                if developer:
                                                    self.db["admin"].remove(mention)
                                                    self.antijs["js"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Admin to Bot's.", [mention])
                                            elif mention in self.db["staff"]:
                                                if admin:
                                                    self.db["staff"].remove(mention)
                                                    self.antijs["js"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Staff to Bot's.", [mention])
                                            elif mention in self.db["whitelist"]:
                                                self.db["whitelist"].remove(mention)
                                                self.antijs["js"].append(mention)
                                                self.sendMention(to, "@!, has been Demoted from Whitelist to Bot's.", [mention])
                                            elif mention in self.antijs["js"]:
                                                self.sendMention(to, "@!, is already in Bot's.", [mention])
                                            elif mention in self.db["blacklist"]:
                                                self.db["blacklist"].remove(mention)
                                                self.antijs["js"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted from Blacklist to Bot's.", [mention])
                                            else:
                                                self.antijs["js"].append(mention)
                                                self.sendMention(to, "@!, has been Promoted to Bot's.", [mention])
                                            self.save_db()
                                else:
                                    if cmd[6:] == "on" or squad[6:] == "on":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["jsbot"] = True
                                        self.set["add_del"]["repeat"] = False
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Bot's.")
                                    if cmd[6:] == "repeat" or squad[6:] == "repeat":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["jsbot"] = True
                                        self.set["add_del"]["repeat"] = True
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Bot's.")
                            if cmd.startswith("expel:") or squad.startswith("expel:"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    if cmd.startswith("expel:on") or squad.startswith("expel:on"):
                                        targets = []
                                        key = eval(msg.contentMetadata["MENTION"])
                                        for x in key["MENTIONEES"]:targets.append(x["M"])
                                        for mention in targets:
                                            if mention in self.db["developer"]:
                                                self.sendMessage(to, "Can't Expel Developer!")
                                            elif mention in self.db["owner"]:
                                                if sender in self.db["developer"]:
                                                    self.db["owner"].remove(mention)
                                                    self.sendMention(to, "@!, has been Expel from Owner.", [mention])
                                                else:
                                                    self.sendMessage(to, "Permission Denied!")
                                            elif mention in self.db["admin"]:
                                                if developer:
                                                    self.db["admin"].remove(mention)
                                                    self.sendMention(to, "@!, has been Expel from Admin.", [mention])
                                                else:
                                                    self.sendMessage(to, "Permission Denied!")
                                            elif mention in self.db["staff"]:
                                                if admin:
                                                    self.db["staff"].remove(mention)
                                                    self.sendMention(to, "@!, has been Expel from Staff.", [mention])
                                                else:
                                                    self.sendMessage(to, "Permission Denied!")
                                            elif mention in self.db["whitelist"]:
                                                if staff:
                                                    self.db["whitelist"].remove(mention)
                                                    self.sendMention(to, "@!, has been Expel from Whitelist.", [mention])
                                                else:
                                                    self.sendMessage(to, "Permission Denied!")
                                            elif mention in self.db["bots"]:
                                                if staff:
                                                    self.db["bots"].remove(mention)
                                                    self.sendMention(to, "@!, has been Expel from Bot's.", [mention])
                                                else:
                                                    self.sendMessage(to, "Permission Denied!")
                                            elif mention in self.antijs["js"]:
                                                if staff:
                                                    self.antijs["js"].remove(mention)
                                                    self.sendMention(to, "@!, has been Expel from Bot's.", [mention])
                                                else:
                                                    self.sendMessage(to, "Permission Denied!")
                                            elif mention in self.db["blacklist"]:
                                                if admin:
                                                    self.db["blacklist"].remove(mention)
                                                    self.sendMention(to, "@!, has been Expel from Blacklist.", [mention])
                                                else:
                                                    self.sendMessage(to, "Permission Denied!")
                                            else:
                                                self.sendMention(to, "@!, not found in DataBase!", [mention])
                                            self.save_db()
                                else:
                                    if cmd[6:] == "on" or squad[6:] == "on":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["expel"] = True
                                        self.set["add_del"]["repeat"] = False
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to Expel user from DataBase.")
                                    if cmd[6:] == "repeat" or squad[6:] == "repeat":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["expel"] = True
                                        self.set["add_del"]["repeat"] = True
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to Expel user from DataBase.")

                        """ KICK & INVITE """
                        if admin:
                            if cmd.startswith("kick") or squad.startswith("kick"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    targets = []
                                    key = eval(msg.contentMetadata["MENTION"])
                                    for x in key["MENTIONEES"]:targets.append(x["M"])
                                    for mention in targets:
                                        if mention in self.db["developer"]:
                                            self.sendMessage(to, "Can't kick Developer!")
                                        elif mention in self.db["owner"]:
                                            self.sendMessage(to, "Can't kick Owner!")
                                        elif mention in self.db["admin"]:
                                            self.sendMessage(to, "Can't kick Admin!")
                                        elif mention in self.db["staff"]:
                                            self.sendMessage(to, "Can't kick Staff!")
                                        elif mention in self.db["whitelist"]:
                                            self.sendMessage(to, "Can't kick Whitelist!")
                                        elif mention in self.db["bots"]:
                                            self.sendMessage(to, "Can't kick Bot's!")
                                        else:
                                            threading.Thread(target=self.kickoutFromGroup(to, [mention])).start()
                            if cmd.startswith("add") or squad.startswith("add"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    targets = []
                                    key = eval(msg.contentMetadata["MENTION"])
                                    for x in key["MENTIONEES"]:targets.append(x["M"])
                                    for mention in targets:
                                        self.findAndAddContactsByMid(mention);self.sendMessage(to, "Berhasil Menambahkan Sebagai Teman")
                            if cmd.startswith("vkick") or squad.startswith("vkick"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    targets = []
                                    key = eval(msg.contentMetadata["MENTION"])
                                    for x in key["MENTIONEES"]:targets.append(x["M"])
                                    for mention in targets:
                                        if mention in self.db["developer"]:
                                            self.sendMessage(to, "Can't kick Developer!")
                                        elif mention in self.db["owner"]:
                                            self.sendMessage(to, "Can't kick Owner!")
                                        elif mention in self.db["admin"]:
                                            self.sendMessage(to, "Can't kick Admin!")
                                        elif mention in self.db["staff"]:
                                            self.sendMessage(to, "Can't kick Staff!")
                                        elif mention in self.db["whitelist"]:
                                            self.sendMessage(to, "Can't kick Whitelist!")
                                        elif mention in self.db["bots"]:
                                            self.sendMessage(to, "Can't kick Bot's!")
                                        else:
                                            self.findAndAddContactsByMid(mention);self.kickoutFromGroup(to, [mention]);self.inviteIntoGroup(to, [mention]);self.cancelGroupInvitation(to, [mention])
                            if cmd == "pendings" or squad == "pendings":
                                group = self.getCompactGroup(to)
                                pending_list = [contact.mid for contact in group.invitee]
                                pending_xyz = []
                                for xyzs in pending_list:
                                    pending_xyz.append(xyzs)
                                if len(pending_list) > 0:self.newMention(to, "Pendings List", pending_xyz)
                                else:self.sendMessage(to, "Pendings List is empty.")
                            if cmd.startswith("cancel"):
                                group = self.getCompactGroup(to)
                                xyzs = self.simplifySplit(text.replace(text[:len(rname)+7],""))
                                pending_list = [contact.mid for contact in group.invitee]
                                for xyz in xyzs:self.cancelGroupInvitation(to, [pending_list[xyz]])

                        """ PROTECTION """
                        if staff:
                            if cmd == "protection:0" or squad == "protection:0" or cmd == "protection:1" or squad == "protection:1" or cmd == "protection:2" or squad == "protection:2":
                                if cmd[11:] == "0" or squad[11:] == "0":
                                    setPro = self.set["protect"]
                                    if to not in setPro["kick"]["1"] and to not in setPro["qrcode"]["1"] and to not in setPro["invite"]["1"] and to not in setPro["cancel"]["1"] and to not in setPro["name"]["1"] and to not in setPro["icon"]["1"] and to not in setPro["kick"]["2"] and to not in setPro["qrcode"]["2"] and to not in setPro["invite"]["2"] and to not in setPro["cancel"]["2"] and to not in setPro["name"]["2"] and to not in setPro["icon"]["2"] and to not in setPro["join"] and to not in self.antijs["group"]:
                                        self.sendMessage(to, "All protection already disabled.")
                                    else:
                                        if to in setPro["kick"]["1"]:setPro["kick"]["1"].remove(to)
                                        if to in setPro["qrcode"]["1"]:setPro["qrcode"]["1"].remove(to);del self.set["backup"]["qrcode"][to]
                                        if to in setPro["invite"]["1"]:setPro["invite"]["1"].remove(to)
                                        if to in setPro["cancel"]["1"]:setPro["cancel"]["1"].remove(to)
                                        if to in setPro["name"]["1"]:setPro["name"]["1"].remove(to);del self.set["backup"]["name"][to]
                                        if to in setPro["icon"]["1"]:setPro["icon"]["1"].remove(to);del self.set["backup"]["icon"][to]
                                        if to in setPro["kick"]["2"]:setPro["kick"]["2"].remove(to)
                                        if to in setPro["qrcode"]["2"]:setPro["qrcode"]["2"].remove(to)
                                        if to in setPro["invite"]["2"]:setPro["invite"]["2"].remove(to)
                                        if to in setPro["cancel"]["2"]:setPro["cancel"]["2"].remove(to)
                                        if to in setPro["name"]["2"]:setPro["name"]["2"].remove(to)
                                        if to in setPro["icon"]["2"]:setPro["icon"]["2"].remove(to)
                                        if to in setPro["join"]:setPro["join"].remove(to)
                                        if to in self.antijs["group"]:self.antijs["group"].remove(to)
                                        self.sendMessage(to, "All protection disabled.")
                                    group = self.getCompactGroup(to)
                                    pending_list = [contact.mid for contact in group.invitee]
                                    pending_xyz = []
                                    for xyzs in pending_list:
                                        pending_xyz.append(xyzs)
                                        if xyzs in self.antijs["js"]:self.cancelGroupInvitation(to, self.antijs["js"])
                                if cmd[11:] == "1" or squad[11:] == "1":
                                    setPro = self.set["protect"]
                                    if to in setPro["kick"]["1"] and to in setPro["qrcode"]["1"] and to in setPro["invite"]["1"] and to in setPro["cancel"]["1"] and to in setPro["name"]["1"] and to in setPro["icon"]["1"]:
                                        self.set["backup"]["name"][to] = self.getCompactGroup(to).name
                                        self.set["backup"]["icon"][to] = self.downloadFileURL("http://dl.profile.line-cdn.net/"+self.getGroup(to).pictureStatus)
                                        self.set["backup"]["qrcode"][to] = self.getCompactGroup(to).preventedJoinByTicket
                                        self.sendMessage(to, "Protection already enabled.")
                                    else:
                                        if to not in setPro["kick"]["1"]:setPro["kick"]["1"].append(to)
                                        if to not in setPro["qrcode"]["1"]:setPro["qrcode"]["1"].append(to)
                                        if to not in setPro["invite"]["1"]:setPro["invite"]["1"].append(to)
                                        if to not in setPro["cancel"]["1"]:setPro["cancel"]["1"].append(to)
                                        if to not in setPro["name"]["1"]:setPro["name"]["1"].append(to)
                                        if to not in setPro["icon"]["1"]:setPro["icon"]["1"].append(to)
                                        self.set["backup"]["name"][to] = self.getCompactGroup(to).name
                                        self.set["backup"]["icon"][to] = self.downloadFileURL("http://dl.profile.line-cdn.net/"+self.getGroup(to).pictureStatus)
                                        self.set["backup"]["qrcode"][to] = self.getCompactGroup(to).preventedJoinByTicket
                                        self.sendMessage(to, "Protection has been enabled.")
                                if cmd[11:] == "2" or squad[11:] == "2":
                                    setPro = self.set["protect"]
                                    if to in setPro["kick"]["2"] and to in setPro["qrcode"]["2"] and to in setPro["invite"]["2"] and to in setPro["cancel"]["2"] and to in setPro["name"]["2"] and to in setPro["icon"]["2"] and to in setPro["join"] and to in self.antijs["group"]:
                                        self.set["backup"]["name"][to] = self.getCompactGroup(to).name
                                        self.set["backup"]["icon"][to] = self.downloadFileURL("http://dl.profile.line-cdn.net/"+self.getGroup(to).pictureStatus)
                                        self.set["backup"]["qrcode"][to] = self.getCompactGroup(to).preventedJoinByTicket
                                        self.sendMessage(to, "Max protection already enabled.")
                                    else:
                                        if to not in setPro["kick"]["1"]:setPro["kick"]["1"].append(to)
                                        if to not in setPro["qrcode"]["1"]:setPro["qrcode"]["1"].append(to)
                                        if to not in setPro["invite"]["1"]:setPro["invite"]["1"].append(to)
                                        if to not in setPro["cancel"]["1"]:setPro["cancel"]["1"].append(to)
                                        if to not in setPro["name"]["1"]:setPro["name"]["1"].append(to)
                                        if to not in setPro["icon"]["1"]:setPro["icon"]["1"].append(to)
                                        if to not in setPro["kick"]["2"]:setPro["kick"]["2"].append(to)
                                        if to not in setPro["qrcode"]["2"]:setPro["qrcode"]["2"].append(to)
                                        if to not in setPro["invite"]["2"]:setPro["invite"]["2"].append(to)
                                        if to not in setPro["cancel"]["2"]:setPro["cancel"]["2"].append(to)
                                        if to not in setPro["name"]["2"]:setPro["name"]["2"].append(to)
                                        if to not in setPro["icon"]["2"]:setPro["icon"]["2"].append(to)
                                        if to not in self.antijs["group"]:self.antijs["group"].append(to)
                                        self.set["backup"]["name"][to] = self.getCompactGroup(to).name
                                        self.set["backup"]["icon"][to] = self.downloadFileURL("http://dl.profile.line-cdn.net/"+self.getGroup(to).pictureStatus)
                                        self.set["backup"]["qrcode"][to] = self.getCompactGroup(to).preventedJoinByTicket
                                        self.sendMessage(to, "Max protection enabled.")
                                    for xyz in self.antijs["js"]:
                                        if xyz != self.profile.mid:self.findAndAddContactsByMid(xyz)
                                    self.inviteIntoGroup(to, self.antijs["js"])
                                self.save_set()
                                self.save_antijs()
                            if cmd == "promember:0" or squad == "promember:0" or cmd == "promember:1" or squad == "promember:1" or cmd == "promember:2" or squad == "promember:2":
                                if cmd[10:] == "0" or squad[10:] == "0":
                                    setPro = self.set["protect"]
                                    if to not in setPro["kick"]["1"] and to not in setPro["kick"]["2"]:
                                        self.sendMessage(to, "Protection Kick already disabled.")
                                    else:
                                        if to in setPro["kick"]["1"]:setPro["kick"]["1"].remove(to)
                                        if to in setPro["kick"]["2"]:setPro["kick"]["2"].remove(to)
                                        self.sendMessage(to, "Protection Kick has been disabled.")
                                if cmd[10:] == "1" or squad[10:] == "1":
                                    setPro = self.set["protect"]
                                    if to in setPro["kick"]["1"]:
                                        self.sendMessage(to, "Protection Kick already enabled.")
                                    else:
                                        setPro["kick"]["1"].append(to)
                                        self.sendMessage(to, "Protection Kick has been enabled.")
                                if cmd[10:] == "2" or squad[10:] == "2":
                                    setPro = self.set["protect"]
                                    if to in setPro["kick"]["1"] and to in setPro["kick"]["2"]:
                                        self.sendMessage(to, "Protection Kick already enabled.")
                                    else:
                                        setPro["kick"]["1"].append(to)
                                        setPro["kick"]["2"].append(to)
                                        self.sendMessage(to, "Protection Kick has been enabled.")
                                self.save_set()
                            if cmd == "prolink:0" or squad == "prolink:0" or cmd == "prolink:1" or squad == "prolink:1" or cmd == "prolink:2" or squad == "prolink:2":
                                if cmd[8:] == "0" or squad[8:] == "0":
                                    setPro = self.set["protect"]
                                    if to not in setPro["qrcode"]["1"] and to not in setPro["qrcode"]["2"]:
                                        self.sendMessage(to, "Protection QR already disabled.")
                                    else:
                                        if to in setPro["qrcode"]["1"]:setPro["qrcode"]["1"].remove(to)
                                        if to in setPro["qrcode"]["2"]:setPro["qrcode"]["2"].remove(to)
                                        del self.set["backup"]["qrcode"][to]
                                        self.sendMessage(to, "Protection QR has been disabled.")
                                if cmd[8:] == "1" or squad[8:] == "1":
                                    setPro = self.set["protect"]
                                    if to in setPro["qrcode"]["1"]:
                                        self.set["backup"]["qrcode"][to] = self.getCompactGroup(to).preventedJoinByTicket
                                        self.sendMessage(to, "Protection QR already enabled.")
                                    else:
                                        setPro["qrcode"]["1"].append(to)
                                        self.set["backup"]["qrcode"][to] = self.getCompactGroup(to).preventedJoinByTicket
                                        self.sendMessage(to, "Protection QR has been enabled.")
                                if cmd[8:] == "2" or squad[8:] == "2":
                                    setPro = self.set["protect"]
                                    if to in setPro["qrcode"]["1"] and to in setPro["qrcode"]["2"]:
                                        self.set["backup"]["qrcode"][to] = self.getCompactGroup(to).preventedJoinByTicket
                                        self.sendMessage(to, "Protection QR already enabled.")
                                    else:
                                        if to not in setPro["qrcode"]["1"]:setPro["qrcode"]["1"].append(to)
                                        if to not in setPro["qrcode"]["2"]:setPro["qrcode"]["2"].append(to)
                                        self.set["backup"]["qrcode"][to] = self.getCompactGroup(to).preventedJoinByTicket
                                        self.sendMessage(to, "Protection QR has been enabled.")
                                self.save_set()
                            if cmd == "denyinvite:0" or squad == "denyinvite:0" or cmd == "denyinvite:1" or squad == "denyinvite:1" or cmd == "denyinvite:2" or squad == "denyinvite:2":
                                if cmd[11:] == "0" or squad[11:] == "0":
                                    setPro = self.set["protect"]
                                    if to not in setPro["invite"]["1"] and to not in setPro["invite"]["2"]:
                                        self.sendMessage(to, "Protection Invite already disabled.")
                                    else:
                                        if to not in setPro["invite"]["1"]:setPro["invite"]["1"].remove(to)
                                        if to not in setPro["invite"]["2"]:setPro["invite"]["2"].remove(to)
                                        self.sendMessage(to, "Protection Invite has been disabled.")
                                if cmd[11:] == "1" or squad[11:] == "1":
                                    setPro = self.set["protect"]
                                    if to in setPro["invite"]["1"]:
                                        self.sendMessage(to, "Protection Invite already enabled.")
                                    else:
                                        setPro["invite"]["1"].append(to)
                                        self.sendMessage(to, "Protection Invite has been enabled.")
                                if cmd[11:] == "2" or squad[11:] == "2":
                                    setPro = self.set["protect"]
                                    if to in setPro["invite"]["1"] and to in setPro["invite"]["2"]:
                                        self.sendMessage(to, "Protection Invite already enabled.")
                                    else:
                                        if to not in setPro["invite"]["1"]:setPro["invite"]["1"].append(to)
                                        if to not in setPro["invite"]["2"]:setPro["invite"]["2"].append(to)
                                        self.sendMessage(to, "Protection Invite has been enabled.")
                                self.save_set()
                            if cmd == "denycancel:0" or squad == "denycancel:0" or cmd == "denycancel:1" or squad == "denycancel:1" or cmd == "denycancel:2" or squad == "denycancel:2":
                                if cmd[11:] == "0" or squad[11:] == "0":
                                    setPro = self.set["protect"]
                                    if to not in setPro["cancel"]["1"] and to not in setPro["cancel"]["2"]:
                                        self.sendMessage(to, "Protection Cancel already disabled.")
                                    else:
                                        if to in setPro["cancel"]["1"]:setPro["cancel"]["1"].remove(to)
                                        if to in setPro["cancel"]["2"]:setPro["cancel"]["2"].remove(to)
                                        self.sendMessage(to, "Protection Cancel has been disabled.")
                                if cmd[11:] == "1" or squad[11:] == "1":
                                    setPro = self.set["protect"]
                                    if to in setPro["cancel"]["1"]:
                                        self.sendMessage(to, "Protection Cancel already enabled.")
                                    else:
                                        setPro["cancel"]["1"].append(to)
                                        self.sendMessage(to, "Protection Cancel has been enabled.")
                                if cmd[11:] == "2" or squad[11:] == "2":
                                    setPro = self.set["protect"]
                                    if to in setPro["cancel"]["1"] and to in setPro["cancel"]["2"]:
                                        self.sendMessage(to, "Protection Cancel already enabled.")
                                    else:
                                        if to not in setPro["cancel"]["1"]:setPro["cancel"]["1"].append(to)
                                        if to not in setPro["cancel"]["2"]:setPro["cancel"]["2"].append(to)
                                        self.sendMessage(to, "Protection Cancel has been enabled.")
                                self.save_set()
                            if cmd == "namelock:0" or squad == "namelock:0" or cmd == "namelock:1" or squad == "namelock:1" or cmd == "namelock:2" or squad == "namelock:2":
                                if cmd[9:] == "0" or squad[9:] == "0":
                                    setPro = self.set["protect"]
                                    if to not in setPro["name"]["1"] and to not in setPro["name"]["2"]:
                                        self.sendMessage(to, "Protection Name already disabled.")
                                    else:
                                        if to in setPro["name"]["1"]:setPro["name"]["1"].remove(to)
                                        if to in setPro["name"]["2"]:setPro["name"]["2"].remove(to)
                                        del self.set["backup"]["name"][to]
                                        self.sendMessage(to, "Protection Name has been disabled.")
                                if cmd[9:] == "1" or squad[9:] == "1":
                                    setPro = self.set["protect"]
                                    if to in setPro["name"]["1"]:
                                        self.set["backup"]["name"][to] = self.getCompactGroup(to).name
                                        self.sendMessage(to, "Protection Name already enabled.")
                                    else:
                                        setPro["name"]["1"].append(to)
                                        self.set["backup"]["name"][to] = self.getCompactGroup(to).name
                                        self.sendMessage(to, "Protection Name has been enabled.")
                                if cmd[9:] == "2" or squad[9:] == "2":
                                    setPro = self.set["protect"]
                                    if to in setPro["name"]["1"] and to in setPro["name"]["2"]:
                                        self.set["backup"]["name"][to] = self.getCompactGroup(to).name
                                        self.sendMessage(to, "Protection Name already enabled.")
                                    else:
                                        if to not in setPro["name"]["1"]:setPro["name"]["1"].append(to)
                                        if to not in setPro["name"]["2"]:setPro["name"]["2"].append(to)
                                        self.set["backup"]["name"][to] = self.getCompactGroup(to).name
                                        self.sendMessage(to, "Protection Name has been enabled.")
                                self.save_set()
                            if cmd == "iconlock:0" or squad == "iconlock:0" or cmd == "iconlock:1" or squad == "iconlock:1" or cmd == "iconlock:2" or squad == "iconlock:2":
                                if cmd[9:] == "0" or squad[9:] == "0":
                                    setPro = self.set["protect"]
                                    if to not in setPro["icon"]["1"] and to not in setPro["icon"]["2"]:
                                        self.sendMessage(to, "Protection Icon already disabled.")
                                    else:
                                        if to in setPro["icon"]["1"]:setPro["icon"]["1"].remove(to)
                                        if to in setPro["icon"]["2"]:setPro["icon"]["2"].remove(to)
                                        del self.set["backup"]["icon"][to]
                                        self.sendMessage(to, "Protection Icon has been disabled.")
                                if cmd[9:] == "1" or squad[9:] == "1":
                                    setPro = self.set["protect"]
                                    if to in setPro["icon"]["1"]:
                                        self.set["backup"]["icon"][to] = self.downloadFileURL("http://dl.profile.line-cdn.net/"+self.getGroup(to).pictureStatus)
                                        self.sendMessage(to, "Protection Icon already enabled.")
                                    else:
                                        setPro["icon"]["1"].append(to)
                                        self.set["backup"]["icon"][to] = self.downloadFileURL("http://dl.profile.line-cdn.net/"+self.getGroup(to).pictureStatus)
                                        self.sendMessage(to, "Protection Icon has been enabled.")
                                if cmd[9:] == "2" or squad[9:] == "2":
                                    setPro = self.set["protect"]
                                    if to in setPro["icon"]["1"] and to in setPro["icon"]["2"]:
                                        self.set["backup"]["icon"][to] = self.downloadFileURL("http://dl.profile.line-cdn.net/"+self.getGroup(to).pictureStatus)
                                        self.sendMessage(to, "Protection Icon already enabled.")
                                    else:
                                        if to not in setPro["icon"]["1"]:setPro["icon"]["1"].append(to)
                                        if to not in setPro["icon"]["2"]:setPro["icon"]["2"].append(to)
                                        self.set["backup"]["icon"][to] = self.downloadFileURL("http://dl.profile.line-cdn.net/"+self.getGroup(to).pictureStatus)
                                        self.sendMessage(to, "Protection Icon has been enabled.")
                                self.save_set()
                            if cmd == "autopurge:on" or squad == "autopurge:on" or cmd == "autopurge:off" or squad == "autopurge:off":
                                if cmd[10:] == "on" or squad[10:] == "on":
                                    setPro = self.set["protect"]
                                    if to in setPro["join"]:
                                        self.sendMessage(to, "Auto Purge already ENABLED.")
                                    else:
                                        setPro["join"].append(to)
                                        self.sendMessage(to, "Auto Purge has been ENABLED.")
                                if cmd[10:] == "off" or squad[10:] == "off":
                                    setPro = self.set["protect"]
                                    if to not in setPro["join"]:
                                        self.sendMessage(to, "Auto Purge already DISABLED.")
                                    else:
                                        setPro["join"].remove(to)
                                        self.sendMessage(to, "Auto Purge has been DISABLED.")
                                self.save_set()
                            if cmd == "antijs:on" or squad == "antijs:on" or cmd == "antijs:off" or squad == "antijs:off":
                                if cmd[7:] == "on" or squad[7:] == "on":
                                    if to in self.antijs["group"]:
                                        self.sendMessage(to, "Anti JS already ENABLED.")
                                    else:
                                        self.antijs["group"].append(to)
                                        self.sendMessage(to, "Anti JS has been ENABLED.")
                                    for xyz in self.antijs["js"]:
                                        if xyz != self.profile.mid:self.findAndAddContactsByMid(xyz)
                                    self.inviteIntoGroup(to, self.antijs["js"])
                                if cmd[7:] == "off" or squad[7:] == "off":
                                    if to not in self.antijs["group"]:
                                        self.sendMessage(to, "Anti JS already DISABLED.")
                                    else:
                                        self.cancelGroupInvitation(to, self.antijs["js"])
                                        self.antijs["group"].remove(to)
                                        self.sendMessage(to, "Anti JS has been DISABLED.")
                                        self.save_antijs()

                            """ BAN & UNBAN """
                            if cmd.startswith("ban:") or squad.startswith("ban:"):
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    if cmd.startswith("ban:on") or squad.startswith("ban:on"):
                                        targets = []
                                        key = eval(msg.contentMetadata["MENTION"])
                                        for x in key["MENTIONEES"]:targets.append(x["M"])
                                        for mention in targets:
                                            if mention in self.db["developer"]:
                                                self.sendMessage(to, "Can't add Developer to Blacklist!")
                                            elif mention in self.db["owner"]:
                                                if sender in self.db["developer"]:
                                                    self.db["owner"].remove(mention)
                                                    self.db["blacklist"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Owner to Blacklist.", [mention])
                                            elif mention in self.db["admin"]:
                                                if developer:
                                                    self.db["admin"].remove(mention)
                                                    self.db["blacklist"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Admin to Blacklist.", [mention])
                                            elif mention in self.db["staff"]:
                                                if admin:
                                                    self.db["staff"].remove(mention)
                                                    self.db["blacklist"].append(mention)
                                                    self.sendMention(to, "@!, has been Demoted from Staff to Blacklist.", [mention])
                                            elif mention in self.db["whitelist"]:
                                                self.db["whitelist"].remove(mention)
                                                self.db["blacklist"].append(mention)
                                                self.sendMention(to, "@!, has been Demoted from Whitelist to Blacklist.", [mention])
                                            elif mention in self.db["bots"]:
                                                self.db["bots"].remove(mention)
                                                self.db["blacklist"].append(mention)
                                                self.sendMention(to, "@!, has been Demoted from Bot's to Blacklist.", [mention])
                                            elif mention in self.db["blacklist"]:
                                                self.sendMention(to, "@!, is already in Blacklist.", [mention])
                                            else:
                                                self.db["blacklist"].append(mention)
                                                self.sendMention(to, "@!, has been add to Blacklist.", [mention])
                                            self.save_db()
                                            self.save_antijs()
                                else:
                                    if cmd[4:] == "on" or squad[4:] == "on":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["blacklist"] = True
                                        self.set["add_del"]["repeat"] = False
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Blacklist.")
                                    if cmd[4:] == "repeat" or squad[4:] == "repeat":
                                        self.ClearRepeat(to)
                                        self.set["add_del"]["blacklist"] = True
                                        self.set["add_del"]["repeat"] = True
                                        self.save_set()
                                        self.sendMessage(to, "Send Contact's to make as Blacklist.")
                            if cmd == "repeat:off" or squad == "repeat:off":
                                if self.set["add_del"]["repeat"]:self.set["add_del"]["repeat"] = False;self.ClearRepeat(to);self.save_set();self.sendMessage(to, "Repeat has been disabled.")
                                else:self.sendMessage(to, "Repeat already disabled.")
                            if cmd.startswith("addwordban ") or squad.startswith("addwordban ") or cmd.startswith("delwordban ") or squad.startswith("delwordban ") or cmd == "wordban:on" or squad == "wordban:on" or cmd == "wordban:off" or squad == "wordban:off":
                                if cmd.startswith("addwordban "):
                                    txt = text.replace(text[:len(rname) + 11],"").lower()
                                    if txt not in self.set["protect"]["wordban"]["list"]:
                                        self.set["protect"]["wordban"]["list"].append(txt)
                                        self.save_set()
                                        self.sendMessage(to, "Command's '%s' has been add to Wordban." % txt)
                                    else:
                                        self.sendMessage(to, "Command's '%s' already in Wordban!" % txt)
                                if squad.startswith("addwordban "):
                                    txt = text.replace(text[:len(sname) + 11],"").lower()
                                    if txt not in self.set["protect"]["wordban"]["list"]:
                                        self.set["protect"]["wordban"]["list"].append(txt)
                                        self.save_set()
                                        self.sendMessage(to, "Command's '%s' has been add to Wordban." % txt)
                                    else:
                                        self.sendMessage(to, "Command's '%s' already in Wordban!" % txt)
                                if cmd.startswith("delwordban "):
                                    txt = text.replace(text[:len(rname) + 11],"").lower()
                                    if txt in self.set["protect"]["wordban"]["list"]:
                                        self.set["protect"]["wordban"]["list"].remove(txt)
                                        self.save_set()
                                        self.sendMessage(to, "Command's '%s' has been removed from Wordban." % txt)
                                    else:
                                        self.sendMessage(to, "Command's '%s' not found in Wordban!" % txt)
                                if squad.startswith("delwordban "):
                                    txt = text.replace(text[:len(sname) + 11],"").lower()
                                    if txt in self.set["protect"]["wordban"]["list"]:
                                        self.set["protect"]["wordban"]["list"].remove(txt)
                                        self.save_set()
                                        self.sendMessage(to, "Command's '%s' has been removed from Wordban." % txt)
                                    else:
                                        self.sendMessage(to, "Command's '%s' not found in Wordban!" % txt)

                        if admin:
                            """ CLEAR """
                            if cmd == "clearban" or squad == "clearban":
                                if len(self.db["blacklist"]) > 0:
                                    self.sendMessage(to, "All blacklist cleared.")
                                    self.db["blacklist"].clear()
                                    self.save_db()
                                else:
                                    self.sendMessage(to, "Blacklist is empty.")
                            if cmd == "clearwhitelist" or squad == "clearwhitelist":
                                if len(self.db["whitelist"]) > 0:
                                    self.sendMessage(to, "All whitelist cleared.")
                                    self.db["whitelist"].clear()
                                    self.save_db()
                                else:
                                    self.sendMessage(to, "Whitelist is empty.")
                            if cmd == "clearowner" or squad == "clearowner":
                                if len(self.db["owner"]) > 0:
                                    self.sendMessage(to, "All owner cleared.")
                                    self.db["owner"].clear()
                                    self.save_db()
                                else:
                                    self.sendMessage(to, "Ownerlist is empty.")
                            if cmd == "clearadmin" or squad == "clearadmin":
                                if len(self.db["admin"]) > 0:
                                    self.sendMessage(to, "All admin cleared.")
                                    self.db["admin"].clear()
                                    self.save_db()
                                else:
                                    self.sendMessage(to, "Adminlist is empty.")
                            if cmd == "clearstaff" or squad == "clearstaff":
                                if len(self.db["staff"]) > 0:
                                    self.sendMessage(to, "All staff cleared.")
                                    self.db["staff"].clear()
                                    self.save_db()
                                else:
                                    self.sendMessage(to, "Staff list is empty.")
                            if cmd == "clearbots" or squad == "clearbots":
                                if len(self.db["bots"]) > 0:
                                    self.sendMessage(to, "All bot's cleared.")
                                    self.db["bots"].clear()
                                    self.save_db()
                                else:
                                    self.sendMessage(to, "Bot's list is empty.")
                            if cmd == "restart" or squad == "restart":
                                self.set["start"] = time.time()
                                self.save_set()
                                self.save_db()
                                self.save_antijs()
                                self.sendMessage(to, "Bot's has been restarted!")
                                self.removeAllMessages(op.param2)
                                python = sys.executable
                                os.execl(python, python, *sys.argv)
                            if cmd == "refresh" or squad == "refresh":
                                self.removeAllMessages(op.param2)
                                self.save_set()
                                with open('db.json','r',encoding='utf-8') as fp:self.db = json.load(fp)
                                with open('antijs.json','r',encoding='utf-8') as fp:self.antijs = json.load(fp)
                                self.sendMessage(to, "Refreshed.")
                        if developer:
                            if cmd.startswith("updatename"):self.updateProfileName(to, text.replace(text[:len(rname)+10],""))
                            if squad.startswith("updatename"):self.updateProfileName(to, text.replace(text[:len(sname)+10],""))
                            if cmd.startswith("updatestatus"):
                                txt = text.replace(text[:len(rname)+12],"")
                                if len(txt.split("\n")) >= 2:xyzr = self.profile;xyzr.statusMessage = txt.replace(txt.split("\n")[0]+"\n","");self.updateProfileAttribute(16, xyzr.statusMessage);self.sendMessage(to, "StatusMessage has been updated to \n%s" % (self.profile.statusMessage))
                            if squad.startswith("updatestatus"):
                                txt = text.replace(text[:len(rname)+12],"")
                                if len(txt.split("\n")) >= 2:xyzr = self.profile;xyzr.statusMessage = txt.replace(txt.split("\n")[0]+"\n","");self.updateProfileAttribute(16, xyzr.statusMessage);self.sendMessage(to, "StatusMessage has been updated to \n%s" % (self.profile.statusMessage))
                            if cmd == "updatepicture" or squad == "updatepicture":self.set["update"]["pict"] = True;self.save_set();self.sendMessage(to, "Send Image for update Picture Profile!")
                            #if cmd == "updatevideo" or squad == "updatevideo":self.set["update"]["video"] = True;self.sendMessage(to, "Send Video for update Video Profile!")
                            if cmd == "updatedual" or squad == "updatedual":self.set["update"]["dual"] = "pict";self.save_set();self.sendMessage(to, "Send Image for update Picture Profile!")
                            if cmd == "addbots" or squad == "addbots":
                                if len(self.db["bots"]) > 0:
                                    for xyz in self.db["bots"]:
                                        if self.profile.mid not in xyz:
                                            self.findAndAddContactsByMid(xyz)
                                    self.newMention(to, "Add Bot's", self.db["bots"])
                                else:
                                    self.sendMessage(to, "Bot's list is empty.")

            if msg.contentType == 1:
                if self.set["update"]["pict"]:
                    path = self.downloadObjectMsg(msg.id)
                    self.set["update"]["pict"] = False
                    self.updateProfilePicture(path)
                    self.sendMessage(to, "Picture Profile has been updated.")
                if self.set["update"]["dual"] == "pict":
                    path = self.downloadObjectMsg(msg.id, saveAs="image.jpg")
                    self.set["update"]["dual"] = "video"
                    self.set["update"]["profile"]["pict"] = path
                    self.sendMessage(to, "Send Video for update Video Profile!")
                if msg.toType == 2:
                    if to in self.set["update"]["gpict"]:
                        path = self.downloadObjectMsg(msg.id)
                        self.set["update"]["gpict"].remove(to)
                        self.updateGroupPicture(to, path)
                        self.sendMessage(to, "Group Picture has been updated.")
            if msg.contentType == 2:
                if self.set["update"]["dual"] == "video":
                    path = self.downloadObjectMsg(msg.id, saveAs="video.mp4")
                    self.set["update"]["dual"] = False
                    self.set["update"]["profile"]["video"] = path
                    self.updatePictureAndVideo(self.set["update"]["profile"]["pict"], self.set["update"]["profile"]["video"])
                    self.sendMessage(to, "Picture & Video profile has been updated.")
            if msg.contentType == 13:
              if sender in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"]:
                uid = msg.contentMetadata["mid"]
                if self.set["add_del"]["owner"] and sender in self.db["developer"]:
                    if not self.set["add_del"]["repeat"]:self.set["add_del"]["owner"] = False
                    if uid in self.db["developer"]:self.sendMessage(to, "Can't Demote from Developer to Owner!")
                    elif uid in self.db["owner"]:self.sendMention(to, "@!, is already in Owner.", [uid])
                    elif uid in self.db["admin"]:self.db["admin"].index(uid);self.db["admin"].remove(uid);self.db["owner"].append(uid);self.sendMention(to, "@!, has been Promoted from Admin to Owner.", [uid])
                    elif uid in self.db["staff"]:self.db["staff"].index(uid);self.db["staff"].remove(uid);self.db["owner"].append(uid);self.sendMention(to, "@!, has been Promoted from Staff to Owner.", [uid])
                    elif uid in self.db["whitelist"]:self.db["whitelist"].index(uid);self.db["whitelist"].remove(uid);self.db["owner"].append(uid);self.sendMention(to, "@!, has been Promoted from Whitelist to Owner.", [uid])
                    elif uid in self.db["bots"]:self.db["bots"].index(uid);self.db["bots"].remove(uid);self.db["owner"].append(uid);self.sendMention(to, "@!, has been Promoted from Bot's to Owner.", [uid])
                    elif uid in self.antijs["js"]:self.antijs["js"].index(uid);self.antijs["js"].remove(uid);self.db["owner"].append(uid);self.save_antijs();self.sendMention(to, "@!, has been Promoted from Bot's to Owner.", [uid])
                    elif uid in self.db["blacklist"]:self.db["blacklist"].index(uid);self.db["blacklist"].remove(uid);self.db["owner"].append(uid);self.sendMention(to, "@!, has been Promoted from Blacklist to Owner.", [uid])
                    else:self.db["owner"].append(uid);self.sendMention(to, "@!, has been Promoted to Owner.", [uid])
                    self.save_db()
                    self.save_set()
                if self.set["add_del"]["admin"] and sender in self.db["developer"] + self.db["owner"]:
                    if not self.set["add_del"]["repeat"]:self.set["add_del"]["admin"] = False
                    if uid in self.db["developer"]:self.sendMessage(to, "Can't Demote from Developer to Admin!")
                    elif uid in self.db["owner"]:self.db["owner"].index(uid);self.db["owner"].remove(uid);self.db["admin"].append(uid);self.sendMention(to, "@!, has been Demote from Owner to Admin.", [uid])
                    elif uid in self.db["admin"]:self.sendMention(to, "@!, is already in Admin.", [uid])
                    elif uid in self.db["staff"]:self.db["staff"].index(uid);self.db["staff"].remove(uid);self.db["admin"].append(uid);self.sendMention(to, "@!, has been Promoted from Staff to Admin.", [uid])
                    elif uid in self.db["whitelist"]:self.db["whitelist"].index(uid);self.db["whitelist"].remove(uid);self.db["admin"].append(uid);self.sendMention(to, "@!, has been Promoted from Whitelist to Admin.", [uid])
                    elif uid in self.db["bots"]:self.db["bots"].index(uid);self.db["bots"].remove(uid);self.db["admin"].append(uid);self.sendMention(to, "@!, has been Promoted from Bot's to Admin.", [uid])
                    elif uid in self.antijs["js"]:self.antijs["js"].index(uid);self.antijs["js"].remove(uid);self.db["admin"].append(uid);self.save_antijs();self.sendMention(to, "@!, has been Promoted from Bot's to Admin.", [uid])
                    elif uid in self.db["blacklist"]:self.db["blacklist"].index(uid);self.db["blacklist"].remove(uid);self.db["admin"].append(uid);self.sendMention(to, "@!, has been Promoted from Blacklist to Admin.", [uid])
                    else:self.db["admin"].append(uid);self.sendMention(to, "@!, has been Promoted to Admin.", [uid])
                    self.save_db()
                    self.save_set()
                if self.set["add_del"]["staff"] and sender in self.db["developer"] + self.db["owner"] + self.db["admin"]:
                    if not self.set["add_del"]["repeat"]:self.set["add_del"]["staff"] = False
                    if uid in self.db["developer"]:self.sendMessage(to, "Can't Demote from Developer to Admin!")
                    elif uid in self.db["owner"]:self.db["owner"].index(uid);self.db["owner"].remove(uid);self.db["staff"].append(uid);self.sendMention(to, "@!, has been Demote from Owner to Staff.", [uid])
                    elif uid in self.db["admin"]:self.db["admin"].index(uid);self.db["admin"].remove(uid);self.db["staff"].append(uid);self.sendMention(to, "@!, has been Demote from Admin to Staff.", [uid])
                    elif uid in self.db["staff"]:self.sendMention(to, "@!, is already in Staff.", [uid])
                    elif uid in self.db["whitelist"]:self.db["whitelist"].index(uid);self.db["whitelist"].remove(uid);self.db["staff"].append(uid);self.sendMention(to, "@!, has been Promoted from Whitelist to Staff.", [uid])
                    elif uid in self.db["bots"]:self.db["bots"].index(uid);self.db["bots"].remove(uid);self.db["staff"].append(uid);self.sendMention(to, "@!, has been Promoted from Bot's to Staff.", [uid])
                    elif uid in self.antijs["js"]:self.antijs["js"].index(uid);self.antijs["js"].remove(uid);self.db["staff"].append(uid);self.save_antijs();self.sendMention(to, "@!, has been Promoted from Bot's to Staff.", [uid])
                    elif uid in self.db["blacklist"]:self.db["blacklist"].index(uid);self.db["blacklist"].remove(uid);self.db["staff"].append(uid);self.sendMention(to, "@!, has been Promoted from Blacklist to Staff.", [uid])
                    else:self.db["staff"].append(uid);self.sendMention(to, "@!, has been Promoted to Staff.", [uid])
                    self.save_db()
                    self.save_set()
                if self.set["add_del"]["whitelist"] and sender in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"]:
                    if not self.set["add_del"]["repeat"]:self.set["add_del"]["whitelist"] = False
                    if uid in self.db["developer"]:self.sendMessage(to, "Can't Demote from Developer to Admin!")
                    elif uid in self.db["owner"]:
                        if sender in self.db["developer"]:self.db["owner"].index(uid);self.db["owner"].remove(uid);self.db["whitelist"].append(uid);self.sendMention(to, "@!, has been Demote from Owner to Whitelist.", [uid])
                    elif uid in self.db["admin"]:
                        if sender in self.db["developer"] + self.db["owner"]:self.db["admin"].index(uid);self.db["admin"].remove(uid);self.db["whitelist"].append(uid);self.sendMention(to, "@!, has been Demote from Admin to Whitelist.", [uid])
                    elif uid in self.db["staff"]:
                        if sender in self.db["developer"] + self.db["owner"] + self.db["admin"]:self.db["staff"].index(uid);self.db["staff"].remove(uid);self.db["whitelist"].append(uid);self.sendMention(to, "@!, has been Demote from Staff to Whitelist.", [uid])
                    elif uid in self.db["whitelist"]:self.sendMention(to, "@!, is already in Whitelist.", [uid])
                    elif uid in self.db["bots"]:self.db["bots"].index(uid);self.db["bots"].remove(uid);self.db["whitelist"].append(uid);self.sendMention(to, "@!, has been Promoted from Bot's to Whitelist.", [uid])
                    elif uid in self.antijs["js"]:self.antijs["js"].index(uid);self.antijs["js"].remove(uid);self.db["whitelist"].append(uid);self.save_antijs();self.sendMention(to, "@!, has been Promoted from Bot's to Whitelist.", [uid])
                    elif uid in self.db["blacklist"]:self.db["blacklist"].index(uid);self.db["blacklist"].remove(uid);self.db["whitelist"].append(uid);self.sendMention(to, "@!, has been Promoted from Blacklist to Whitelist.", [uid])
                    else:self.db["whitelist"].append(uid);self.sendMention(to, "@!, has been Promoted to Whitelist.", [uid])
                    self.save_db()
                    self.save_set()
                if self.set["add_del"]["bots"] and sender in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"]:
                    if not self.set["add_del"]["repeat"]:self.set["add_del"]["bots"] = False
                    if uid in self.db["developer"]:self.sendMessage(to, "Can't Demote from Developer to Bot's!")
                    elif uid in self.db["owner"]:
                        if sender in self.db["developer"]:self.db["owner"].index(uid);self.db["owner"].remove(uid);self.db["bots"].append(uid);self.sendMention(to, "@!, has been Demote from Owner to Bot's.", [uid])
                    elif uid in self.db["admin"]:
                        if sender in self.db["developer"] + self.db["owner"]:self.db["admin"].index(uid);self.db["admin"].remove(uid);self.db["bots"].append(uid);self.sendMention(to, "@!, has been Demote from Admin to Bot's.", [uid])
                    elif uid in self.db["staff"]:
                        if sender in self.db["developer"] + self.db["owner"] + self.db["admin"]:self.db["staff"].index(uid);self.db["staff"].remove(uid);self.db["bots"].append(uid);self.sendMention(to, "@!, has been Demote from Staff to Bot's.", [uid])
                    elif uid in self.db["whitelist"]:self.db["whitelist"].index(uid);self.db["whitelist"].remove(uid);self.db["bots"].append(uid);self.sendMention(to, "@!, has been Demote from Whitelist to Bot's.", [uid])
                    elif uid in self.db["bots"]:self.sendMention(to, "@!, is already in Bot's.", [uid])
                    elif uid in self.antijs["js"]:self.antijs["js"].index(uid);self.antijs["js"].remove(uid);self.db["bots"].append(uid);self.save_antijs();self.sendMention(to, "@!, is already in Bot's.", [uid])
                    elif uid in self.db["blacklist"]:self.db["blacklist"].index(uid);self.db["blacklist"].remove(uid);self.db["bots"].append(uid);self.sendMention(to, "@!, has been Promoted from Blacklist to Bot's.", [uid])
                    else:self.db["bots"].append(uid);self.sendMention(to, "@!, has been Promoted to Bot's.", [uid])
                    self.save_db()
                    self.save_set()
                if self.set["add_del"]["jsbot"] and sender in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"]:
                    if not self.set["add_del"]["repeat"]:self.set["add_del"]["jsbot"] = False
                    if uid in self.db["developer"]:self.sendMessage(to, "Can't Demote from Developer to Bot's!")
                    elif uid in self.db["owner"]:
                        if sender in self.db["developer"]:self.db["owner"].index(uid);self.db["owner"].remove(uid);self.antijs["js"].append(uid);self.sendMention(to, "@!, has been Demote from Owner to Bot's.", [uid])
                    elif uid in self.db["admin"]:
                        if sender in self.db["developer"] + self.db["owner"]:self.db["admin"].index(uid);self.db["admin"].remove(uid);self.antijs["js"].append(uid);self.sendMention(to, "@!, has been Demote from Admin to Bot's.", [uid])
                    elif uid in self.db["staff"]:
                        if sender in self.db["developer"] + self.db["owner"] + self.db["admin"]:self.db["staff"].index(uid);self.db["staff"].remove(uid);self.antijs["js"].append(uid);self.sendMention(to, "@!, has been Demote from Staff to Bot's.", [uid])
                    elif uid in self.db["whitelist"]:self.db["whitelist"].index(uid);self.db["whitelist"].remove(uid);self.antijs["js"].append(uid);self.sendMention(to, "@!, has been Demote from Whitelist to Bot's.", [uid])
                    elif uid in self.db["bots"]:self.db["bots"].index(uid);self.db["bots"].remove(uid);self.antijs["js"].append(uid);self.sendMention(to, "@!, is already in Bot's.", [uid])
                    elif uid in self.antijs["js"]:self.sendMention(to, "@!, is already in Bot's.", [uid])
                    elif uid in self.db["blacklist"]:self.db["blacklist"].index(uid);self.db["blacklist"].remove(uid);self.antijs["js"].append(uid);self.sendMention(to, "@!, has been Promoted from Blacklist to Bot's.", [uid])
                    else:self.antijs["js"].append(uid);self.sendMention(to, "@!, has been Promoted to Bot's.", [uid])
                    self.save_db()
                    self.save_antijs()
                    self.save_set()
                if self.set["add_del"]["blacklist"] and sender in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"]:
                    if not self.set["add_del"]["repeat"]:self.set["add_del"]["blacklist"] = False
                    if uid in self.db["developer"]:self.sendMessage(to, "Can't Demote from Developer to Bot's!")
                    elif uid in self.db["owner"]:
                        if sender in self.db["developer"]:self.db["owner"].index(uid);self.db["owner"].remove(uid);self.db["blacklist"].append(uid);self.sendMention(to, "@!, has been Demote from Owner to Blacklist.", [uid])
                    elif uid in self.db["admin"]:
                        if sender in self.db["developer"] + self.db["owner"]:self.db["admin"].index(uid);self.db["admin"].remove(uid);self.db["blacklist"].append(uid);self.sendMention(to, "@!, has been Demote from Admin to Blacklist.", [uid])
                    elif uid in self.db["staff"]:
                        if sender in self.db["developer"] + self.db["owner"] + self.db["admin"]:self.db["staff"].index(uid);self.db["staff"].remove(uid);self.db["blacklist"].append(uid);self.sendMention(to, "@!, has been Demote from Staff to Blacklist.", [uid])
                    elif uid in self.db["whitelist"]:self.db["whitelist"].index(uid);self.db["whitelist"].remove(uid);self.db["blacklist"].append(uid);self.sendMention(to, "@!, has been Demote from Whitelist to Blacklist.", [uid])
                    elif uid in self.db["bots"]:self.db["bots"].index(uid);self.db["bots"].remove(uid);self.db["blacklist"].append(uid);self.sendMention(to, "@!, has been Demote from Bot's to Blacklist.", [uid])
                    elif uid in self.antijs["js"]:self.antijs["js"].index(uid);self.antijs["js"].remove(uid);self.db["blacklist"].append(uid);self.save_antijs();self.sendMention(to, "@!, has been Demote from Bot's to Blacklist.", [uid])
                    elif uid in self.db["blacklist"]:self.sendMention(to, "@!, is already in Blacklist.", [uid])
                    else:self.db["blacklist"].append(uid);self.sendMention(to, "@!, has been Promoted to Blacklist.", [uid])
                    self.save_db()
                    self.save_set()
                if self.set["add_del"]["expel"] and sender in self.db["developer"] + self.db["owner"] + self.db["admin"] + self.db["staff"]:
                    if not self.set["add_del"]["repeat"]:self.set["add_del"]["expel"] = False
                    if uid in self.db["developer"]:self.sendMessage(to, "Can't expel Developer!")
                    elif uid in self.db["owner"]:
                        if sender in self.db["developer"]:self.db["owner"].index(uid);self.db["owner"].remove(uid);self.sendMention(to, "@!, has been Expel from Owner.", [uid])
                    elif uid in self.db["admin"]:
                        if sender in self.db["developer"] + self.db["owner"]:self.db["admin"].index(uid);self.db["admin"].remove(uid);self.sendMention(to, "@!, has been Expel from Admin.", [uid])
                    elif uid in self.db["staff"]:
                        if sender in self.db["developer"] + self.db["owner"] + self.db["admin"]:self.db["staff"].index(uid);self.db["staff"].remove(uid);self.sendMention(to, "@!, has been Expel from Staff.", [uid])
                    elif uid in self.db["whitelist"]:self.db["whitelist"].index(uid);self.db["whitelist"].remove(uid);self.sendMention(to, "@!, has been Expel from Whitelist.", [uid])
                    elif uid in self.db["bots"]:self.db["bots"].index(uid);self.db["bots"].remove(uid);self.sendMention(to, "@!, has been Expel from Bot's.", [uid])
                    elif uid in self.antijs["js"]:self.antijs["js"].index(uid);self.antijs["js"].remove(uid);self.save_antijs();self.sendMention(to, "@!, has been Expel from Bot's.", [uid])
                    elif uid in self.db["blacklist"]:self.db["blacklist"].index(uid);self.db["blacklist"].remove(uid);self.sendMention(to, "@!, has been Expel from Blacklist.", [uid])
                    else:self.sendMention(to, "@!, not found in DataBase!", [uid])
                    self.save_db()
                    self.save_set()
