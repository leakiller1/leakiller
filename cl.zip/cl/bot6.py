from line import *
from threading import Thread
import sys, os, traceback, asyncio

token = "u5efb56cd537432a449880fb3acf9ada3:aWF0OiAxNTcxMjk2MzQ2MjUyCg==..8qsjh2NXXJq/kFSRUHlGAhago94="
line = LINE(token)
event_loop = asyncio.get_event_loop()

async def run():
    while 1:
        try:
            en = line.poll.fetchOperations(line.revision, 50)
            for op in en:
                if op.type != 0:
                    line.revision = max(line.revision, op.revision)
                    if op.type == OpType.NOTIFIED_UPDATE_GROUP:Thread(target=line.notified_update_group(op)).start()
                    if op.type == OpType.NOTIFIED_INVITE_INTO_GROUP:Thread(target=line.notified_invite_into_group(op)).start()
                    if op.type == OpType.NOTIFIED_LEAVE_GROUP:Thread(target=line.notified_leave_group(op)).start()
                    if op.type == OpType.NOTIFIED_ACCEPT_GROUP_INVITATION:Thread(target=line.notified_accept_group_invitation(op)).start()
                    if op.type == OpType.NOTIFIED_KICKOUT_FROM_GROUP:Thread(target=line.notified_kickout_from_group(op)).start()
                    if op.type == OpType.NOTIFIED_CANCEL_INVITATION_GROUP:Thread(target=line.notified_cancel_invitation_group(op)).start()
                    if op.type == OpType.RECEIVE_MESSAGE:Thread(target=line.receive_message(op)).start()
                    if op.type == OpType.NOTIFIED_INVITE_INTO_ROOM:Thread(target=line.leave_room(op)).start()
                    if op.type == OpType.NOTIFIED_LEAVE_ROOM:Thread(target=line.leave_room(op)).start()
        except Exception as e:
          e = traceback.format_exc()
          if "EOFError" in e:
              pass
          elif "ShouldSyncException" in e:
              python = sys.executable
              os.execl(python, python, *sys.argv)
          elif "log_out" in e.lower():
              python = sys.executable
              os.execl(python, python, *sys.argv)
          else:
              traceback.print_exc()
if __name__ == '__main__':
    event_loop.run_until_complete(run())