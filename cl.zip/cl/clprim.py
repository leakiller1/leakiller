# -*- coding: utf-8 -*- 
from line import *
from threading import Thread
import sys, os, traceback, asyncio
from multiprocessing import Pool, Process
from time import sleep
import pytz, datetime, pafy, time, timeit, random, sys, ast, re, os, json, subprocess, threading, string, codecs, requests, tweepy, ctypes, urllib, wikipedia
from datetime import timedelta, date
from datetime import datetime
botStart = time.time()

botStart = time.time()
try:os.system('screen -S anuu1 -X quit');os.system('rm -rf clone/anuu1')
except:pass
try:os.system('screen -dmS anuu1');os.system('screen -r anuu1 -X stuff "python3.6 bot1.py \n"')
except:pass
botStart = time.time()
try:os.system('screen -S anuu2 -X quit');os.system('rm -rf clone/anuu2')
except:pass
try:os.system('screen -dmS anuu2');os.system('screen -r anuu2 -X stuff "python3.6 bot2.py \n"')
except:pass
botStart = time.time()
try:os.system('screen -S anuu3 -X quit');os.system('rm -rf clone/anuu3')
except:pass
try:os.system('screen -dmS anuu3');os.system('screen -r anuu3 -X stuff "python3.6 bot3.py \n"')
except:pass
botStart = time.time()
try:os.system('screen -S anuu4 -X quit');os.system('rm -rf clone/anuu4')
except:pass
try:os.system('screen -dmS anuu4');os.system('screen -r anuu4 -X stuff "python3.6 bot4.py \n"')
except:pass
botStart = time.time()
try:os.system('screen -S anuu5 -X quit');os.system('rm -rf clone/anuu5')
except:pass
try:os.system('screen -dmS anuu5');os.system('screen -r anuu5 -X stuff "python3.6 bot5.py \n"')
except:pass
botStart = time.time()
try:os.system('screen -S anuu6 -X quit');os.system('rm -rf clone/anuu6')
except:pass
try:os.system('screen -dmS anuu6');os.system('screen -r anuu6 -X stuff "python3.6 bot6.py \n"')
except:pass
botStart = time.time()
try:os.system('screen -S anuu7 -X quit');os.system('rm -rf clone/anuu7')
except:pass
try:os.system('screen -dmS anuu7');os.system('screen -r anuu7 -X stuff "python3.6 bot7.py \n"')
except:pass
botStart = time.time()
try:os.system('screen -S anuu8 -X quit');os.system('rm -rf clone/anuu8')
except:pass
try:os.system('screen -dmS anuu8');os.system('screen -r anuu8 -X stuff "python3.6 bot8.py \n"')
except:pass
botStart = time.time()
try:os.system('screen -S anuu9 -X quit');os.system('rm -rf clone/anuu9')
except:pass
try:os.system('screen -dmS anuu9');os.system('screen -r anuu9 -X stuff "python3.6 bot9.py \n"')
except:pass
botStart = time.time()
try:os.system('screen -S anuu10 -X quit');os.system('rm -rf clone/anuu10')
except:pass
try:os.system('screen -dmS anuu10');os.system('screen -r anuu10 -X stuff "python3.6 ajs.py \n"')
except:pass
botStart = time.time()
try:os.system('screen -S anuu11 -X quit');os.system('rm -rf clone/anuu11')
except:pass
try:os.system('screen -dmS anuu11');os.system('screen -r anuu11 -X stuff "python3.6 ajs1.py \n"')
except:pass
print ("ALL BOTS HAS BEEN RUNNING !!!!")