import os

bots = [
    "anuu1",
    "anuu2",
    "anuu3",
    "anuu4",
    "anuu5",
    "anuu6",
    "anuu7",
    "anuu8",
    "anuu9",
    "anuu10",
    "anuu11"
]


for xyz in bots:
    os.system("screen -S %s -X kill" % xyz)
    #os.system("screen -S %s -dm python3 %s.py kill" % (xyz, xyz))