from line import *
from threading import Thread
import sys, os, traceback, livejson

token = "u24890b6cd2cda7bc4eebe3b991cf4f0c:aWF0OiAxNTcxNjY4MjI0MTE5Cg==..tkOVvyy2HaWWKyXJ7qhM5hF9nrk="
line = LINE(token)

def run():
    while True:
        try:
            en = line.poll.fetchOperations(line.revision, 50)
            for op in en:
                if op.type != 0:
                    line.revision = max(line.revision, op.revision)
                    if op.type == OpType.NOTIFIED_KICKOUT_FROM_GROUP:Thread(target=line.antijs_notified_kickout_from_group(op)).start()
                    if op.type == OpType.RECEIVE_MESSAGE:Thread(target=line.receive_message(op)).start()
                    if op.type == OpType.NOTIFIED_INVITE_INTO_ROOM:Thread(target=line.leave_room(op)).start()
                    if op.type == OpType.NOTIFIED_LEAVE_ROOM:Thread(target=line.leave_room(op)).start()
        except Exception as e:
          e = traceback.format_exc()
          if "EOFError" in e:
              pass
          elif "log_out" in e.lower():
              python = sys.executable
              os.execl(python, python, *sys.argv)
          else:
              traceback.print_exc()
if __name__ == '__main__':
    run()
